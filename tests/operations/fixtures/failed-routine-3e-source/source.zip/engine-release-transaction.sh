#!/usr/bin/env bash
# One crash-contained Club Arena engine release transaction.
#
# The root-owned systemd unit keeps this transaction alive if SSH or its
# GitHub runner disappears. It owns prepare, cutover, all three compatibility
# witnesses, the fsynced release seal, and deterministic recovery.
set -euo pipefail

CONTROL_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
RELEASE_SEAL="$CONTROL_DIR/engine-release-seal.py"
ENGINE_UP="$CONTROL_DIR/engine-up.sh"
IMAGE_BUILDER="$CONTROL_DIR/build-engine-image.sh"
DATABASE_PROOF="$CONTROL_DIR/engine-release-database-proof.py"
INFLIGHT_HANDS="$CONTROL_DIR/engine-release-inflight-hands.py"
LIGHTNING_HOLD="$CONTROL_DIR/engine-release-lightning-hold.py"
LEGACY_CHECKPOINT="$CONTROL_DIR/legacy-engine-checkpoint.sh"
LEGACY_CHECKPOINT_SHA=2f4e33560bcd23bfb5cc731f31816b2c2e2847e5
CHECKPOINT_758_SHA=758610f3f844406bbbaee2f5100ced36d84fb943
CHECKPOINT_A0_SHA=a0ab287d902879280f0c915e44f5222c5db4d7df
CHECKPOINT_8825_SHA=8825af51817f379c4261658ca29ecc9d8d81932d
CHECKPOINT_EED_SHA=eed06fe51dea622069c661a6213d5b031ff3a9e3
# The compatibility floors in docs/dr/diamond-release-manifest.md section 4: below
# the first an engine cannot read Diamond custody, below the second it deals a
# Diamond tournament table as a chip table. A rollback drill target holds both.
DRILL_ENGINE_FLOOR_SHA=86aab0e645b1842e83fca808cf956c9733af66ba
DRILL_TOURNAMENT_FLOOR_SHA=ab9e626376c96b9ce2b74a45833428f0875450d3
REPO_DIR="${REPO_DIR:-/opt/club-arena}"
ENV_FILE="${ENV_FILE:-$REPO_DIR/server/.env}"
REQUEST_ROOT="${ENGINE_RELEASE_REQUEST_ROOT:-/var/lib/club-arena/engine-release-requests}"
LEASE_ROOT="${ENGINE_RELEASE_IMAGE_LEASE_ROOT:-/var/lib/club-arena/engine-image-leases}"
ENGINE_LOCK="${ENGINE_LOCK_FILE:-/var/lock/club-arena-engine-up.lock}"
SOURCE_LOCK="${SOURCE_LOCK_FILE:-/var/lock/club-arena-source.lock}"
CONTAINER="${CONTAINER:-club-arena-engine}"
IMAGE_REPO="${IMAGE_REPO:-club-arena-engine}"
PUBLIC_URL="${ENGINE_URL:-https://engine.smarter.poker}"
MAX_RUNTIME_SECONDS="${ENGINE_RELEASE_MAX_RUNTIME_SECONDS:-8400}"
CERTIFICATE_RESERVE_SECONDS=720
# Five-to-eight-minute boots have occurred while the database was degraded, so
# a fixed five-minute break cannot promise recovery from every external outage.
# It can support an ordinary release only when the currently sealed engine is
# demonstrably the exact live local/public process AND the fresh database leader
# immediately before mutation. Recent healthy releases complete the whole
# candidate proof in about two minutes. Give candidate proof 150 seconds,
# reserve 135 seconds for exact desired recovery, and require that this
# 285-second budget still exists under the engine lock. The remaining nominal
# 15 seconds are entry slack for lock/freshness/certificate work. Every command
# after the certificate shares the absolute break deadline; if dependencies
# degrade after the readiness proof, recovery fails loudly rather than claiming
# an impossible in-break guarantee.
BREAK_CUTOVER_PROOF_SECONDS=150
BREAK_ROLLBACK_RESERVE_SECONDS=135
BREAK_DEADLINE_SLACK_SECONDS=0
# THE LEGACY CHECKPOINT GETS THE SECONDS IT NEEDS (2026-09-21)
# ───────────────────────────────────────────────────────────
# The engine's countdown is BREAK_DURATION_MS, 300000ms, every break. The
# strict 285000ms certificate above leaves 15 seconds of entry slack, and the
# legacy 8825 checkpoint has to fit inside it: countdown detection, the
# rollback proof, the helper preamble AND the publisher's bounded work. In run
# 35615604946 the sequence reached the guard's first check 15.2 seconds into
# the countdown and it refused with insufficient_reserve, as the arithmetic
# says it always must. So the checkpoint's whole budget is written down here
# and taken out of the CANDIDATE PROOF budget, never the rollback reserve.
# The budget is what the transaction ACTUALLY PAYS between the admission and
# the guard's last check, all of it measured:
#   entry     ~15000ms  countdown detection (~4.7s, one 5s poll), the
#                       rollback proof (~5.3s) and the helper preamble
#                       (~5.2s) on run 35615604946, then the intent write
#                       and the guard's own node boot
#   work       20000ms  legacy-engine-checkpoint.mjs workBudgetMs
#   cleanup     5000ms  legacy-engine-checkpoint.mjs cleanupBudgetMs
#   budget     40000ms  LEGACY_CHECKPOINT_BUDGET_SECONDS
# The guard holds reserveMs = 285 - 40 = 245 seconds at EVERY check, and the
# certificate read after the checkpoint accepts the same 245000ms, which still
# holds the full 135-second rollback reserve and leaves 110 seconds of
# candidate proof against the 51-112 seconds sealed runs have measured: a
# proof at the top of that range now rolls back inside the untouched reserve
# instead of sealing, and the changelog says so. The checkpoint may only START
# inside the 285000ms entry slack; that entry check, and the ordinary
# certificate for every non-legacy release, do not move. The first cut of this
# (25 seconds, 260000ms) budgeted the publisher's work and left the ~15s entry
# to fit inside the 15s the break has above 285000, which is the same
# impossibility one gate later.
LEGACY_CHECKPOINT_BUDGET_SECONDS=40
# The figures above describe the measured split, not independent allowances.
# ENTRY_STARTED_MS fixes one absolute deadline before the initial countdown.
# Native work may consume unused entry headroom, always reserving its final
# five seconds for cleanup; neither the forty seconds nor the certificate grows.
# The publisher's bounded work inside that budget, from the .mjs figures
# above; what is left of the budget is the allowance for the entry.
LEGACY_CHECKPOINT_WORK_MS=25000
# THE EED PREDECESSOR IS REPLACED AT A DRAINED HAND BOUNDARY (owner, 2026-10-31)
# ───────────────────────────────────────────────────────────────────────────
# Engine eed06fe5 was the only legacy profile whose checkpoint discovers its
# owners with a full-heap native census (V8 HeapProfiler::QueryObjects). That
# census has never fitted on the live engine. Measured by the previous release
# agent on an application-shaped heap: 11-12 ms of single-core work per MB of
# used heap; at the live 3.85 GB the census needs ~45 s, against the 30.3 s the
# census request was actually granted inside the 40 s checkpoint budget at
# 19:55Z on 2026-10-31 (run 41233374402, checkpoint at elapsedEntryMs=2915,
# 35000 ms of work less the measured entry and guard boot). Each attempt held
# the predecessor's main thread for 45-60 s and the 19:55Z break stayed frozen
# for 1512 s. A freshly restarted eed06fe5 passes 2.3 GB inside an hour.
#
# So the census is only ever entered when the predecessor's own /health heap
# reading, at the conservative 12 ms/MB, fits the 30300 ms allowance. That is
# decided BEFORE any notice is requested, and again immediately before the
# one-shot intent. Otherwise the census is refused before notice and this
# release may replace eed06fe5 only at a DRAINED HAND BOUNDARY: the strict
# restart certificate (readyForRestart, zero unparked tables, no bounded-F06
# admission) plus the database's own witness that no tournament hand is
# reserved or retained and no hand anywhere is moving
# (engine-release-inflight-hands.py --drained-predecessor). No hand is
# checkpointed, voided, forced or invented; every ceiling is unchanged.
LEGACY_CENSUS_MS_PER_HEAP_MB=12
LEGACY_CENSUS_ALLOWANCE_MS=30300
NON_BREAK_RECOVERY_MAX_SECONDS=300
# CLAUDE.md 13: routine activation starts at 04:00 America/Chicago. This is the same minute every other surface reads, and
# tests/the-break-clocks-agree.law.test.ts pins them together.
BREAK_START_MINUTE=0
MIN_BREAK_REMAINING_MS=$(((BREAK_CUTOVER_PROOF_SECONDS + BREAK_ROLLBACK_RESERVE_SECONDS + BREAK_DEADLINE_SLACK_SECONDS) * 1000))
LEGACY_MIN_BREAK_REMAINING_MS=$(((BREAK_CUTOVER_PROOF_SECONDS + BREAK_ROLLBACK_RESERVE_SECONDS + BREAK_DEADLINE_SLACK_SECONDS - LEGACY_CHECKPOINT_BUDGET_SECONDS) * 1000))
# The engine's break is BREAK_DURATION_MS = 5 * 60 * 1000 in
# server/src/maintenance/MaintenanceBreak.ts, pinned across every surface by
# tests/the-break-clocks-agree.law.test.ts. The strict reserve above takes
# 285000 of it, so 15000ms is all the break has above the entry threshold.
BREAK_WINDOW_MS=300000
# THE ENTRY IS INSIDE THE BUDGET, NOT ABOVE THE THRESHOLD (2026-09-21).
# Four separate gates used to demand the SAME 285000ms against the same
# break: maintenance_certificate, legacy_checkpoint_countdown below, the
# physical probe in legacy-engine-checkpoint.sh, and finally the guard's own
# reserveMs. Between them sit the engine lock, a sealed-SHA read,
# prove_rollback_readiness (about twenty bounded host round trips, a loopback
# probe, a public HTTPS probe and a database leader proof) and a cold node
# boot. BREAK_DEADLINE_SLACK_SECONDS is 0, so none of that was budgeted: an
# admission at 285001ms remaining handed the LAST gate a guaranteed deficit,
# and the refusal was terminal. Run 35615604946 is the measurement - admitted
# with at least 285000ms, the guard read about 272500ms.
# PR #5026 answered by adding a measured entry budget to the ADMISSION
# threshold (285000 + up to 15000). That cannot close either: the countdown
# is 300000ms, the entry costs ~15000ms of it before the guard's first read,
# so after one miss the admission demanded a countdown the engine only offers
# at t=0, and every break deferred. The reconciliation keeps the entry cost
# INSIDE LEGACY_CHECKPOINT_BUDGET_SECONDS (its 15000ms allowance) and moves
# the guard's reserve down to 245000 instead; the admission stays at 285000.
# The allowance is derived, not chosen, and the ceiling on the admission
# headroom is what the break offers above 285000 minus what the budget
# already reserves for the entry: 15000 - 15000 = 0. legacy_checkpoint_
# countdown still takes the headroom argument and the measurement below is
# still taken and logged, so if the budget's arithmetic ever changes the
# ceiling moves with it; today it is 0 and an admission can never be more
# permissive than the strict 285000ms.
LEGACY_ENTRY_ALLOWANCE_MS=$((LEGACY_CHECKPOINT_BUDGET_SECONDS * 1000 - LEGACY_CHECKPOINT_WORK_MS))
BREAK_ENTRY_BUDGET_CEILING_MS=$((BREAK_WINDOW_MS - MIN_BREAK_REMAINING_MS - LEGACY_ENTRY_ALLOWANCE_MS))
BREAK_ENTRY_BUDGET_MS=0
# THE ORDINARY RELEASE IS ADMITTED BY A CERTIFICATE THAT CAN EXIST (2026-09-25)
# ───────────────────────────────────────────────────────────────────────────
# Everything above budgets the LEGACY checkpoint's entry. The ordinary release
# - every release now that the engine is off the four pinned predecessors -
# had no entry budget at all, and it has exactly the same shape of deficit.
#
# `beginCountdown` in server/src/maintenance/MaintenanceBreak.ts starts the
# 300000ms clock, sets breakEndsAt, broadcasts and arms the end timer, and
# only THEN awaits the countdown row's durable save; `durableConfirmed`, which
# maintenance_certificate requires, stays false until that write commits. So
# the first instant this script can observe a certificate at all is already
# several seconds into a countdown that is already running, and the 15000ms
# the strict 285000ms admission leaves has to cover every one of them.
#
# MEASURED, on the host that pays it. Runs 36155409978, 36157652866 and
# 36157811057 logged the first certifiable read of six consecutive breaks at
# 15375, 15939, 16408, 18455, 19060 and 19846ms into the countdown - six out
# of six past the allowance. All three runs then spent their whole two-hour
# deadline refusing every break they were offered, and production drifted
# eight merges behind main again, which is how the September 18-25 outage
# started. The lag is the engine's countdown write plus this script's own
# pre-certificate poll granularity (bounded_sleep 5): 19846 + 5000 = 24846,
# rounded up to the second.
BREAK_CERTIFICATE_LAG_SECONDS=25
# What the ordinary path then pays BETWEEN that admission and the locked read
# that follows it: acquire_engine_lock, source_target_is_current, the exact-
# instance probe and the certificate read itself. The locked read demanded the
# SAME 285000ms the admission had just spent seconds getting past, so a lucky
# admission was handed a guaranteed deficit one gate later - the identical
# fault #5026 and PR #5062 answered for the legacy ladder, still live here.
# The legacy budget already measures this same entry at LEGACY_ENTRY_
# ALLOWANCE_MS (15000ms, run 35615604946) and the ordinary path does strictly
# less work in it: no durable intent write, no publisher, no cold node boot.
BREAK_LOCKED_ENTRY_SECONDS=15
# The descending ladder for a release that needs no legacy checkpoint, in the
# same shape as the legacy one above: each rung is the rollback reserve plus
# the budget that still follows it, so passing an earlier gate implies the
# last one can pass. Every deduction comes out of the CANDIDATE PROOF
# (150 -> 125 -> 110 seconds), never out of BREAK_ROLLBACK_RESERVE_SECONDS,
# and the bottom rung lands on 245000ms - the same floor the legacy ladder
# already holds and the figure run 36154480502 shipped 778075b4 on.
BREAK_ADMISSION_MIN_BREAK_MS=$((MIN_BREAK_REMAINING_MS - BREAK_CERTIFICATE_LAG_SECONDS * 1000))
BREAK_LOCKED_MIN_BREAK_MS=$((BREAK_ADMISSION_MIN_BREAK_MS - BREAK_LOCKED_ENTRY_SECONDS * 1000))

die() {
  echo "[engine-release-transaction] FATAL: $*" >&2
  exit 1
}

# The ladder is derived, so assert the derivation rather than trusting it. A
# future edit that puts the admission above what a 300000ms countdown can
# offer, or takes the locked floor below the reserve the legacy path already
# holds, refuses here - loudly, once, on this host - instead of refusing every
# break in silence for a week.
[ "$BREAK_ADMISSION_MIN_BREAK_MS" -lt "$BREAK_WINDOW_MS" ] \
  || die 'the ordinary break admission demands more countdown than the engine ever offers'
[ "$BREAK_ADMISSION_MIN_BREAK_MS" -ge "$BREAK_LOCKED_MIN_BREAK_MS" ] \
  || die 'the ordinary break ladder does not descend'
[ "$BREAK_LOCKED_MIN_BREAK_MS" -ge "$LEGACY_MIN_BREAK_REMAINING_MS" ] \
  || die 'the ordinary locked floor is below the reserve the legacy ladder already holds'
[ "$BREAK_LOCKED_MIN_BREAK_MS" -gt $((BREAK_ROLLBACK_RESERVE_SECONDS * 1000)) ] \
  || die 'the ordinary locked floor no longer holds the whole rollback reserve'

[ "$(id -u)" = 0 ] || die 'must run as root'
[ "$#" = 2 ] && [ "$1" = --run-id ] \
  || die 'usage: engine-release-transaction.sh --run-id RUN_ID-RUN_ATTEMPT'
RUN_ID="$2"
[[ "$RUN_ID" =~ ^[1-9][0-9]*(-[1-9][0-9]*)?$ ]] || die 'run key is invalid'
GITHUB_RUN_ID="${RUN_ID%%-*}"
[[ "$MAX_RUNTIME_SECONDS" =~ ^[1-9][0-9]*$ ]] || die 'runtime budget must be a positive integer'
[ "$MAX_RUNTIME_SECONDS" -ge 1200 ] && [ "$MAX_RUNTIME_SECONDS" -le 8400 ] \
  || die 'runtime budget must be between twenty minutes and two hours twenty minutes'
STARTED_EPOCH="$(date +%s)"
SUPERSEDED_BY=""
DEADLINE=0
CERTIFICATE_DEADLINE=0
LEGACY_ENTRY_DEADLINE_MS=0

remaining_seconds() {
  local remaining=$((DEADLINE - $(date +%s)))
  [ "$remaining" -gt 0 ] || return 1
  printf '%s\n' "$remaining"
}

# Only the admitted legacy entry uses this clock. Every native read in that
# entry shares its work deadline; the last five seconds remain native cleanup.
# Outside that entry the original command and its own bounds are unchanged.
legacy_entry_read() {
  local remaining_ms budget_duration
  if [ "${LEGACY_ENTRY_DEADLINE_MS:-0}" -eq 0 ]; then "$@"; return; fi
  remaining_ms=$((LEGACY_ENTRY_DEADLINE_MS - $(date +%s%3N) - 5000))
  [ "$remaining_ms" -gt 1000 ] || return 124
  remaining_ms=$((remaining_ms - 1000))
  if [ "${1:-}" = timeout ]; then
    shift
    while [ "$#" -gt 0 ]; do
      case "$1" in --signal=TERM|--kill-after=1s|--kill-after=5s) shift ;; *) break ;; esac
    done
    [[ "${1:-}" =~ ^([1-9][0-9]*)s$ ]] || return 124
    local requested_ms=$((BASH_REMATCH[1] * 1000))
    [ "$requested_ms" -ge "$remaining_ms" ] || remaining_ms="$requested_ms"
    shift
  fi
  printf -v budget_duration '%d.%03ds' "$((remaining_ms / 1000))" "$((remaining_ms % 1000))"
  timeout --signal=TERM --kill-after=1s "$budget_duration" "$@"
}

legacy_entry_trace() {
  local now elapsed remaining window
  now="$(date +%s%3N)"
  elapsed=$((now - ENTRY_STARTED_MS))
  remaining=$((LEGACY_ENTRY_DEADLINE_MS - now))
  window=$((LEGACY_ENTRY_BREAK_END_EPOCH * 1000 - now))
  echo "[engine-release-transaction] legacy entry phase=$1 reason=$2 elapsedEntryMs=$elapsed remainingEntryMs=$remaining remainingWindowMs=$window" >&2
}

assert_time_remaining() {
  remaining_seconds >/dev/null || die 'the end-to-end release deadline expired'
}

bounded_sleep() {
  local requested="$1" remaining proof_remaining
  remaining="$(remaining_seconds)" || die 'the end-to-end release deadline expired while waiting'
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    proof_remaining="$(break_proof_seconds)" \
      || die 'maintenance break proof budget expired while waiting'
    [ "$remaining" -le "$proof_remaining" ] || remaining="$proof_remaining"
  fi
  [ "$requested" -le "$remaining" ] || requested="$remaining"
  sleep "$requested"
}

validate_actor() {
  python3 - "$1" <<'PY'
import sys
actor = sys.argv[1]
valid = bool(actor) and len(actor) <= 128 and all(ord(char) >= 32 and ord(char) != 127 for char in actor)
raise SystemExit(0 if valid else 1)
PY
}

REQUEST_FILE="$REQUEST_ROOT/$RUN_ID.request"
mapfile -t REQUEST_LINES < "$REQUEST_FILE" || die 'release request is missing'
[ "${#REQUEST_LINES[@]}" = 6 ] || die 'release request has an invalid field count'
SHA="${REQUEST_LINES[0]}"
RUN_URL="${REQUEST_LINES[1]}"
ACTOR="${REQUEST_LINES[2]}"
REQUEST_GENERATION="${REQUEST_LINES[3]}"
REQUEST_CONTROL_SHA="${REQUEST_LINES[4]}"
REQUEST_NOT_AFTER_EPOCH="${REQUEST_LINES[5]}"
[[ "$SHA" =~ ^[0-9a-f]{40}$ ]] || die 'request SHA must be one lowercase 40-hex commit'
[ "$RUN_URL" = "https://github.com/Smarter-Poker/Smarter-Poker-Club-Arena/actions/runs/$GITHUB_RUN_ID" ] \
  || die 'request URL does not identify this Club Arena run'
validate_actor "$ACTOR" || die 'request actor is invalid'
[[ "$REQUEST_CONTROL_SHA" =~ ^[0-9a-f]{40}$ ]] || die 'request control SHA is invalid'
[[ "$REQUEST_NOT_AFTER_EPOCH" =~ ^[1-9][0-9]*$ ]] \
  && [ "${#REQUEST_NOT_AFTER_EPOCH}" -le 10 ] \
  || die 'request not-after epoch is invalid'
[ "$REQUEST_GENERATION" = "$CONTROL_DIR" ] \
  || die 'release request does not identify this immutable control generation'
CONTROL_SHA="$(tr -d '\r\n' < "$CONTROL_DIR/control-sha")" \
  || die 'control generation SHA manifest is missing'
[ "$CONTROL_SHA" = "$REQUEST_CONTROL_SHA" ] || die 'control generation SHA does not match the request'

# ROLLBACK DRILLS RIDE THE RELEASE LANE, NEVER BESIDE IT (2026-10-17)
# ─────────────────────────────────────────────────────────────────
# docs/runbooks/maintenance-break-fire-drill.md allows a live drill only as a
# reviewed default-branch repository event with this transaction's own
# controls: exact SHA, pinned host, one release lane, the table-safe break
# certificate, provenance receipts and automatic refusal. A rollback is a
# release, so its drill IS this transaction: .github/workflows/
# engine-rollback-drill.yml is that event, and install-engine-drill.sh writes
# this one root-only record beside the request before handing the run key to
# the unchanged durable intake. A run key with no drill record is an ordinary
# release; nothing below changes for it. (The crash drill is not a release and
# has its own route, engine-crash-drill.sh, under the same engine lock.)
#   rollback     an older release this host has already sealed, through the
#                seal's audited rollback mode, which keeps the high-water
#   rollforward  the sealed high-water release again, after a rollback
# A drill never requests an off-cycle window and never makes a waiting release
# stand aside; a newer waiting release still takes the break from a drill.
DRILL_FILE="$REQUEST_ROOT/$RUN_ID.drill"
DRILL_MODE=''
DRILL_REASON=''
if [ -e "$DRILL_FILE" ] || [ -L "$DRILL_FILE" ]; then
  [ -f "$DRILL_FILE" ] && [ ! -L "$DRILL_FILE" ] || die 'engine drill record is not a regular file'
  [ "$(stat -c '%u:%a' "$DRILL_FILE")" = '0:600' ] \
    || die 'engine drill record ownership or mode is invalid'
  mapfile -t DRILL_LINES < "$DRILL_FILE" || die 'engine drill record is unreadable'
  [ "${#DRILL_LINES[@]}" = 5 ] || die 'engine drill record has an invalid field count'
  [ "${DRILL_LINES[0]}" = engine-drill-v1 ] || die 'engine drill record schema is unknown'
  DRILL_MODE="${DRILL_LINES[1]}"
  case "$DRILL_MODE" in
    rollback|rollforward) ;;
    *) die 'engine drill mode is unknown' ;;
  esac
  [ "${DRILL_LINES[2]}" = "$SHA" ] || die 'engine drill record names a different target'
  [ "${DRILL_LINES[3]}" = "$CONTROL_SHA" ] || die 'engine drill record names a different control commit'
  DRILL_REASON="${DRILL_LINES[4]}"
  [ "${#DRILL_REASON}" -ge 12 ] && validate_actor "$DRILL_REASON" \
    || die 'engine drill reason must be 12 to 128 printable characters'
  echo "[engine-release-transaction] ENGINE DRILL $DRILL_MODE of $SHA under run $RUN_ID: $DRILL_REASON"
fi
# Only a rollback drill prepares the seal's audited rollback mode; a roll
# forward is an ordinary deploy of the high-water.
SEAL_MODE=deploy
SEAL_PREPARE_REASON='normal protected-main engine release'
if [ "$DRILL_MODE" = rollback ]; then
  SEAL_MODE=rollback
  SEAL_PREPARE_REASON="engine drill rollback: $DRILL_REASON"
elif [ -n "$DRILL_MODE" ]; then
  SEAL_PREPARE_REASON="engine drill $DRILL_MODE: $DRILL_REASON"
fi
DRILL_PREVIOUS_DESIRED=''
# The workflow chooses this once, before any network or host handoff. Every
# systemd retry reads the same immutable request byte and can never extend the
# CI-owned mutation window. A shorter per-invocation cap is permitted; a later
# one is not.
MUTATION_DEADLINE_EPOCH="$REQUEST_NOT_AFTER_EPOCH"
LOCAL_RUNTIME_DEADLINE=$((STARTED_EPOCH + MAX_RUNTIME_SECONDS))
[ "$MUTATION_DEADLINE_EPOCH" -le "$LOCAL_RUNTIME_DEADLINE" ] \
  || MUTATION_DEADLINE_EPOCH="$LOCAL_RUNTIME_DEADLINE"
if [ "$MUTATION_DEADLINE_EPOCH" -gt "$STARTED_EPOCH" ]; then
  DEADLINE="$MUTATION_DEADLINE_EPOCH"
else
  # An expired invocation may only restore/finalize exact durable state. Give
  # that recovery path a fresh bounded clock without reopening release work.
  DEADLINE=$((STARTED_EPOCH + NON_BREAK_RECOVERY_MAX_SECONDS))
fi
CERTIFICATE_DEADLINE=$((MUTATION_DEADLINE_EPOCH - CERTIFICATE_RESERVE_SECONDS))
INVOCATION_ID="${INVOCATION_ID:-}"
[[ "$INVOCATION_ID" =~ ^[0-9a-f]{32}$ ]] || die 'systemd invocation identity is missing or invalid'
IMAGE_REF="$IMAGE_REPO:$SHA"
LEASE_FILE="$LEASE_ROOT/$RUN_ID.lease"
BREAK_DEADLINE_FILE="$REQUEST_ROOT/$RUN_ID.break-deadline"

LOCK_HELD=0
PREPARED=0
MUTATION_STARTED=0
LEGACY_CHECKPOINT_INTENT_FILE="$REQUEST_ROOT/$RUN_ID.legacy-checkpoint-intent"
LEGACY_CHECKPOINT_ATTEMPTED=0
refuse_foreign_floor_owner() {
  [ "${FLOOR_DISPOSITION:-legacy}" = never-entered ] || [ "${FLOOR_DISPOSITION:-legacy}" = announced ] || return 0
  local foreign rc
  if foreign="$(newer_release_in_flight any)"; then
    die "fresh scheduled release cannot compete with active runtime owner ${foreign%% *}"
  else
    rc=$?
    [ "$rc" = 1 ] || die 'foreign runtime ownership is unreadable'
  fi
}

retire_unannounced_floor_entry() {
  [ "${FLOOR_RESERVATION_FRESH:-0}" = 1 ] || return 0
  # Only a definitive no-reservation answer, while holding the engine lock,
  # can retire this invocation's new intent. Unknown outcomes retain recovery.
  python3 - "$REQUEST_ROOT" "${ENGINE_RELEASE_STATE_DIR:-/var/lib/club-arena}" "$RUN_ID" <<'FLOOR_NO_ACTION'
import os, sys
from pathlib import Path
root, state, run = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3]
reservation = state / ('engine-recovery-window-' + run + '.json')
if os.path.lexists(reservation): raise SystemExit('reservation exists; entry remains owned')
(root / (run + '.activation-entry')).unlink()
fd = os.open(root, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
try: os.fsync(fd)
finally: os.close(fd)
FLOOR_NO_ACTION
  FLOOR_DISPOSITION=never-entered
  FLOOR_RESERVATION_FRESH=0
}

# THE NEWEST WAITING RELEASE TAKES THE BREAK (2026-09-27). This run's marker
# says "my immutable image is built and I am waiting at the certificate". It is
# never left over from an earlier invocation of the same run key (a systemd
# retry starts again from the build), so it is removed here, before anything
# else, and again on every exit. Only newer_release_awaiting_certificate reads
# it, and only to let an OLDER target stand aside for this one.
AWAITING_CERTIFICATE_FILE="$REQUEST_ROOT/$RUN_ID.awaiting-certificate"
# LIGHTNING IS HELD FOR THE CUTOVER (2026-10-30). The legacy one-shot checkpoint
# refuses with retained_lightning_host_census_unproven while any concrete
# LightningHandHost is alive in the old process, and Lightning deals ~5,600
# hands an hour, so an unheld Lightning floor refuses nearly every break
# (15:55 UTC, 2026-10-30). The break parks classic tables at a hand boundary;
# this parks Lightning the same way, through the Phase 13 operator door
# (fn_lightning_operator_control pause: no new hand forms, hands in the air
# settle, undealt formations are void) as soon as the announced countdown is
# durable, and resumes exactly the Clusters THIS run paused after the thaw.
# The hold is a durable file beside the request so a resume survives this
# process: recover_on_exit releases it on every exit path, and
# engine-release-recover.sh --mode terminal is its second reader.
LIGHTNING_HOLD_FILE="$REQUEST_ROOT/$RUN_ID.lightning-hold.json"
# A retried transaction (systemd Restart after a signalled exit) inherits the
# hold its predecessor could not release: seed from the file, never from 0.
LIGHTNING_HOLD_PLACED=0
[ ! -e "$LIGHTNING_HOLD_FILE" ] || LIGHTNING_HOLD_PLACED=1
[[ "$AWAITING_CERTIFICATE_FILE" =~ ^"$REQUEST_ROOT"/[1-9][0-9]*(-[1-9][0-9]*)?\.awaiting-certificate$ ]] \
  || die 'unsafe awaiting-certificate marker path'
rm -f -- "$AWAITING_CERTIFICATE_FILE"
# THE ONE-SHOT IS DURABLE; THIS VARIABLE IS NOT. A boot-resumed or re-entered
# unit is a fresh process and starts it back at 0, so process memory alone
# cannot answer "has this run key already opened the checkpoint". On 2026-09-21
# run 35626149078 proved it: a first attempt in the 16:41 break wrote its
# O_EXCL intent, the transaction was interrupted ("transient release
# interruption recovered; durable request retained"), the same run key
# re-entered, and the helper was invoked a SECOND time. The O_EXCL guard held -
# which is why nothing was double-applied - but the second invocation should
# never have happened, and what the operator saw was a Python traceback.
# Read the durable record here, once, before any of it (CLAUDE.md 10.11: fix
# the cause, not the symptom).
if [ -e "$LEGACY_CHECKPOINT_INTENT_FILE" ] || [ -L "$LEGACY_CHECKPOINT_INTENT_FILE" ]; then
  LEGACY_CHECKPOINT_ATTEMPTED=1
fi

# Prepare Lightning during this exact owner window's durable last-hand lead.
# Other supported releases retain their existing counting-down admission.
# Idempotent: the helper replays its own request ids, and a placed hold is
# never re-sent. An UNKNOWN answer is retried on the next loop pass; it never
# admits or refuses the checkpoint by itself (the census guard still decides).
hold_lightning_when_counting_down() {
  local response http_code body rc early_stamp=0
  if [ "$LIGHTNING_HOLD_PLACED" = 1 ]; then
    # Continue only an incomplete pausing journal using its exact original IDs.
    # Cleanup is irreversible; a partial or unknown resume cannot re-pause.
    [ -e "$LIGHTNING_HOLD_FILE" ] && python3 -c '
import json, sys
try: d = json.load(open(sys.argv[1]))
except Exception: raise SystemExit(1)
raise SystemExit(0 if d.get("phase") == "pausing" else 1)
' "$LIGHTNING_HOLD_FILE" 2>/dev/null || return 0
  fi
  [ -z "${DRILL_MODE:-}" ] || return 0
  response="$(curl -sS --max-time 2 --write-out $'\n%{http_code}' \
    http://127.0.0.1:8080/health 2>/dev/null)" || return 0
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in 200|503) ;; *) return 0 ;; esac
  # Synchronous operator calls at countdown spent the headroom before
  # the unchanged 285s entry reserve. Prepare only an exact owned announcement
  # during its two-minute lead; this pauses formation, never an active hand.
  if printf '%s' "$body" | python3 -c '
import json,sys
try: d=json.load(sys.stdin)
except Exception: raise SystemExit(1)
m=d.get("maintenance") if isinstance(d,dict) else None
raise SystemExit(0 if isinstance(m,dict) and m.get("phase")=="last_hand" else 1)
' 2>/dev/null; then
    if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
      bind_phase1_window "$body" || return 0
      early_stamp=$((PHASE1_WINDOW_START - 120000))
    else
      [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ] || return 0
      early_stamp="$(floor_reservation_stamp)" || return 0
    fi
    "$INFLIGHT_HANDS" --env-file "$ENV_FILE" --weekly-payout-only >&2 || return 0
    # Re-read after authoritative ownership: a stale announcement cannot be
    # turned into a pause by slow policy/database reads.
    response="$(curl -sS --max-time 2 --write-out $'\n%{http_code}' \
      http://127.0.0.1:8080/health 2>/dev/null)" || return 0
    http_code="${response##*$'\n'}"
    body="${response%$'\n'*}"
    case "$http_code" in 200|503) ;; *) return 0 ;; esac
  fi
  # Only a break this release may actually use. The serving original still
  # announces an hourly :55 break it cannot consume (the countdown refuses
  # everything but the daily 04:00 certificate, a Deployment Recovery window
  # or the one transition break), and a hold placed on those would park
  # Lightning for hours while the release waits. Same predicate as the
  # countdown, evaluated at the announcement instead of at admission.
  printf '%s' "$body" | EARLY_HOLD_STAMP="$early_stamp" DAILY_TRANSITION="${DAILY_TRANSITION:-0}" ACTIVATION_FLOOR_END_EPOCH="${ACTIVATION_FLOOR_END_EPOCH:-0}" ACTIVATION_FLOOR_OWNER_WINDOW="${ACTIVATION_FLOOR_OWNER_WINDOW:-}" python3 -c '
import json, os, sys, time
from datetime import datetime
from zoneinfo import ZoneInfo
try: d = json.load(sys.stdin)
except Exception: raise SystemExit(1)
m = d.get("maintenance") if isinstance(d, dict) else None
if not isinstance(m, dict): raise SystemExit(1)
# An early preparation read cannot fall through to a different countdown.
if int(os.environ.get("EARLY_HOLD_STAMP", "0")) > 0 and m.get("phase") != "last_hand":
    raise SystemExit(1)
if m.get("phase") == "last_hand":
    stamp=int(os.environ.get("EARLY_HOLD_STAMP", "0"))
    floor_end=int(os.environ.get("ACTIVATION_FLOOR_END_EPOCH", "0"))
    p=m.get("presentation")
    cycle=int(os.environ.get("PHASE1_CYCLE_START", "0"))
    if cycle:
        start=int(os.environ.get("PHASE1_WINDOW_START","0")); end=int(os.environ.get("PHASE1_WINDOW_END","0")); planned=start-120000
        schedule=m.get("schedule")
        hourly=isinstance(schedule,dict) and schedule.get("frequency")=="phase1-hourly" and schedule.get("policyId")=="phase1-hourly-01a1944f" and schedule.get("timeZone")=="America/Chicago" and schedule.get("startHour") is None and type(schedule.get("startMinute")) is int and schedule["startMinute"]==0 and type(schedule.get("durationMs")) is int and schedule["durationMs"]==300000 and schedule.get("hourlyCashFreeze") is True
        reason=m.get("reason")
        if not (stamp in (0,planned) and reason in ("Deployment Recovery","Scheduled Engine Maintenance")
                and (reason=="Deployment Recovery" or hourly) and d.get("running") is True
                and "weeklyPayout" in d and d["weeklyPayout"] is None
                and m.get("active") is True and m.get("durableConfirmed") is True
                and isinstance(p,dict) and p.get("active") is True and p.get("phase")=="last_hand"
                and p.get("reason")==reason and type(p.get("break_id")) is int and p["break_id"]==planned
                and type(p.get("break_ends_at")) is int and p["break_ends_at"]==end
                and type(p.get("scheduled_ends_at")) is int and p["scheduled_ends_at"]==end
                and start>0 and planned/1000 <= time.time() < start/1000):
            raise SystemExit(1)
        raise SystemExit(0)
    if not (os.environ.get("ACTIVATION_FLOOR_OWNER_WINDOW") and stamp>0
            and d.get("running") is True and "weeklyPayout" in d and d["weeklyPayout"] is None
            and m.get("active") is True and m.get("durableConfirmed") is True
            and m.get("reason")=="Deployment Recovery" and isinstance(p,dict)
            and p.get("active") is True and p.get("phase")=="last_hand"
            and p.get("reason")=="Deployment Recovery"
            and type(p.get("break_id")) is int and p["break_id"]==stamp
            and type(p.get("break_ends_at")) is int and p["break_ends_at"]==stamp+420000
            and type(p.get("scheduled_ends_at")) is int and p["scheduled_ends_at"]==stamp+420000
            and stamp/1000 <= time.time() < stamp/1000+120
            and stamp/1000+420 <= floor_end):
        raise SystemExit(1)
    raise SystemExit(0)
if not (m.get("active") is True and m.get("phase") == "counting_down" and m.get("durableConfirmed") is True): raise SystemExit(1)
local = datetime.now(ZoneInfo("America/Chicago"))
daily = (local.hour == 3 and local.minute >= 58) or (local.hour == 4 and local.minute < 5)
cycle = int(os.environ.get("PHASE1_CYCLE_START", "0"))
if cycle:
    schedule=m.get("schedule")
    hourly=isinstance(schedule,dict) and schedule.get("frequency")=="phase1-hourly" and schedule.get("policyId")=="phase1-hourly-01a1944f" and schedule.get("timeZone")=="America/Chicago" and schedule.get("startHour") is None and type(schedule.get("startMinute")) is int and schedule["startMinute"]==0 and type(schedule.get("durationMs")) is int and schedule["durationMs"]==300000 and schedule.get("hourlyCashFreeze") is True
    start=int(os.environ.get("PHASE1_WINDOW_START","0")); end=int(os.environ.get("PHASE1_WINDOW_END","0"))
    daily=start>0 and start/1000 <= time.time() < end/1000 and m.get("breakEndsAt")==end and (hourly or m.get("reason")=="Deployment Recovery")
    if not daily: raise SystemExit(1)
emergency = m.get("reason") == "Deployment Recovery"
transition = os.environ.get("DAILY_TRANSITION") == "1" and m.get("schedule") is None and local.minute >= 55 and m.get("reason") == "Scheduled Engine Maintenance"
floor_end = int(os.environ.get("ACTIVATION_FLOOR_END_EPOCH", "0"))
if os.environ.get("ACTIVATION_FLOOR_OWNER_WINDOW"):
    # An owner-window release is admitted only on its Deployment Recovery break.
    ok = emergency
elif floor_end:
    # A daily-floor release is admitted only on the daily break inside its floor.
    ok = daily and m.get("reason") == "Scheduled Engine Maintenance" and floor_end - 300 <= time.time() < floor_end
else:
    ok = daily or emergency or transition
raise SystemExit(0 if ok else 1)
' 2>/dev/null || return 0
  # The helper writes its hold file after every answered Cluster and lists
  # paused Clusters on a retry, so a kill here never strands a paused Cluster;
  # 5 s per call keeps twelve round trips inside the outer budget.
  rc=0
  timeout --signal=TERM --kill-after=2s 90s \
    "$LIGHTNING_HOLD" pause --env-file "$ENV_FILE" --run-id "$RUN_ID" --hold-file "$LIGHTNING_HOLD_FILE" --timeout-seconds 5 || rc=$?
  case "$rc" in
    0|1) LIGHTNING_HOLD_PLACED=1 ;;
    126|127) echo "[engine-release-transaction] WARN: the Lightning hold helper could not run (exit $rc); Lightning was NEVER ASKED to pause this pass and the census guard decides on its own" >&2 ;;
    *) echo "[engine-release-transaction] WARN: the Lightning hold answered UNKNOWN (exit $rc); it is retried on the next pass" >&2 ;;
  esac
  # A hold file written before a kill is a placed hold, whatever the exit code.
  [ ! -e "$LIGHTNING_HOLD_FILE" ] || LIGHTNING_HOLD_PLACED=1
  return 0
}

# A qualifying break that passed without a cutover: give Lightning back now,
# and let the next qualifying break place a fresh hold (new request ids).
release_lightning_hold_if_break_over() {
  local response http_code body
  [ "$LIGHTNING_HOLD_PLACED" = 1 ] || return 0
  response="$(curl -sS --max-time 2 --write-out $'\n%{http_code}' \
    http://127.0.0.1:8080/health 2>/dev/null)" || return 0
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in 200|503) ;; *) return 0 ;; esac
  printf '%s' "$body" | python3 -c '
import json, sys
try: d = json.load(sys.stdin)
except Exception: raise SystemExit(1)
m = d.get("maintenance") if isinstance(d, dict) else None
raise SystemExit(0 if d.get("running") is True and isinstance(m, dict) and m.get("active") is not True else 1)
' 2>/dev/null || return 0
  release_lightning_hold 0 0 1
  # Released means the file is gone. A hold that could not be released keeps
  # LIGHTNING_HOLD_PLACED=1 so this pass runs again and again until it is.
  [ -e "$LIGHTNING_HOLD_FILE" ] || LIGHTNING_HOLD_PLACED=0
  return 0
}

# Release the hold after the thaw, on every exit path and whenever a
# qualifying break has passed. The wait is for the SERVING ENGINE to report the
# break over (the operator door itself is not behind the Postgres freeze), so a
# resume lands on a live floor rather than racing the cutover; it is bounded by
# the latest known break end plus ninety seconds and never more than ten
# minutes. Callable under set -e: every non-zero answer is caught. A hold that
# still cannot be released stays on disk for the next pass or the fence, and
# says so. The second argument is a hard stop epoch for signalled exits.
release_lightning_hold() {
  local exit_code="${1:-0}" stop_epoch="${2:-0}" attempts="${3:-3}" break_end wait_until response http_code body attempt rc budget=60
  [ -e "$LIGHTNING_HOLD_FILE" ] || return 0
  break_end="${BREAK_END_EPOCH:-0}"
  [ "${LEGACY_ENTRY_BREAK_END_EPOCH:-0}" -le "$break_end" ] || break_end="$LEGACY_ENTRY_BREAK_END_EPOCH"
  wait_until=$(( break_end + 90 ))
  [ "$wait_until" -le $(( $(date +%s) + 600 )) ] || wait_until=$(( $(date +%s) + 600 ))
  case "$exit_code" in
    75|130)
      # A signalled exit (systemd stop: TERM/HUP -> 75, INT -> 130) shares the
      # 330 s stop budget with the seal abort and desired recovery that ran
      # before this. One attempt, inside what is left; a refusal keeps the hold
      # on disk for the retried transaction or the fence.
      attempts=1
      [ "$stop_epoch" -gt 0 ] || stop_epoch=$(( $(date +%s) + 60 ))
      budget=$(( stop_epoch - $(date +%s) - 5 ))
      [ "$budget" -ge 10 ] || { echo "[engine-release-transaction] WARN: no stop budget left to release the Lightning hold; $LIGHTNING_HOLD_FILE stays on disk for the retry or the fence" >&2; return 0; }
      [ "$budget" -le 60 ] || budget=60
      [ "$wait_until" -le $(( stop_epoch - budget - 5 )) ] || wait_until=$(( stop_epoch - budget - 5 ))
      ;;
  esac
  while [ "$(date +%s)" -lt "$wait_until" ]; do
    response="$(curl -sS --max-time 2 --write-out $'\n%{http_code}' \
      http://127.0.0.1:8080/health 2>/dev/null)" || { sleep 5; continue; }
    http_code="${response##*$'\n'}"
    body="${response%$'\n'*}"
    case "$http_code" in 200|503) ;; *) sleep 5; continue ;; esac
    if printf '%s' "$body" | python3 -c '
import json, sys
try: d = json.load(sys.stdin)
except Exception: raise SystemExit(1)
m = d.get("maintenance") if isinstance(d, dict) else None
raise SystemExit(0 if d.get("running") is True and isinstance(m, dict) and m.get("active") is not True else 1)
' 2>/dev/null; then
      break
    fi
    sleep 5
  done
  rc=0
  for attempt in $(seq 1 "$attempts"); do
    rc=0
    timeout --signal=TERM --kill-after=2s "${budget}s" \
      "$LIGHTNING_HOLD" resume --env-file "$ENV_FILE" --run-id "$RUN_ID" --hold-file "$LIGHTNING_HOLD_FILE" --timeout-seconds 5 || rc=$?
    [ "$rc" -ne 0 ] || return 0
    [ "$attempt" -lt "$attempts" ] && sleep 15
  done
  echo "[engine-release-transaction] FATAL: the Lightning hold for run $RUN_ID could not be released (exit $rc); $LIGHTNING_HOLD_FILE stays on disk and is retried on the next pass or by engine-release-recover.sh" >&2
  return 0
}

recover_on_exit() {
  local rc=$? recovery_deadline recovery_remaining non_break_deadline exit_started
  trap - EXIT HUP INT TERM
  set +e
  exit_started="$(date +%s)"
  # A run that is leaving no longer waits at the certificate; an older target
  # must not keep standing aside for it while systemd schedules a retry.
  rm -f -- "$AWAITING_CERTIFICATE_FILE"
  recovery_deadline="${BREAK_END_EPOCH:-0}"
  if [ "$recovery_deadline" -le "$(date +%s)" ]; then
    # Recovery is deliberately allowed after the immutable release mutation
    # cutoff. It may restore sealed desired state, never prepare or cut over a
    # new candidate.
    non_break_deadline=$(( $(date +%s) + NON_BREAK_RECOVERY_MAX_SECONDS ))
    recovery_deadline="$non_break_deadline"
  fi
  recovery_remaining=$((recovery_deadline - $(date +%s)))
  if [ "$rc" -ne 0 ] && [ "$PREPARED" = 1 ]; then
    if [ "$recovery_remaining" -gt 2 ]; then
      [ "$recovery_remaining" -le 10 ] || recovery_remaining=10
      timeout --signal=TERM --kill-after=1s "${recovery_remaining}s" \
        "$RELEASE_SEAL" abort --run-id "$RUN_ID" \
        || echo '[engine-release-transaction] FATAL: break-bounded immediate seal abort failed' >&2
    else
      echo '[engine-release-transaction] FATAL: no certified break time remained for seal abort' >&2
    fi
  fi
  if [ "$rc" -ne 0 ] && [ "$MUTATION_STARTED" = 1 ] && [ "$LOCK_HELD" = 1 ]; then
    recovery_remaining=$((recovery_deadline - $(date +%s)))
    if [ "$recovery_remaining" -gt 2 ]; then
      timeout --signal=TERM --kill-after=1s "${recovery_remaining}s" env \
        ENGINE_SUPERVISOR_LOCK_HELD=1 ENGINE_SUPERVISOR_FORCE_DESIRED=1 \
        ENGINE_SUPERVISOR_REQUIRE_EXACT_HEALTH=1 \
        ENGINE_RECOVERY_DEADLINE_EPOCH="$recovery_deadline" \
        ENGINE_CONTROL_DIR="$CONTROL_DIR" CONTAINER="$CONTAINER" \
        ENGINE_URL="$PUBLIC_URL" "$CONTROL_DIR/engine-supervisor.sh" \
        || echo '[engine-release-transaction] FATAL: break-bounded exact desired recovery failed' >&2
    else
      # The cutover gate below makes this unreachable for new transactions.
      # Keep the failure loud for a transaction started by older control bytes.
      echo '[engine-release-transaction] FATAL: certified recovery deadline already expired' >&2
    fi
  elif [ "$rc" -ne 0 ] && [ "$MUTATION_STARTED" = 1 ]; then
    echo '[engine-release-transaction] WARN: deferred recovery to ExecStopPost because the engine lock is not held' >&2
  fi
  if [ "$LOCK_HELD" = 1 ]; then
    flock -u 9
    LOCK_HELD=0
  fi
  # After the engine lock is released: waiting for the thaw must not keep the
  # supervisor or a successor release out of the lock for minutes.
  release_lightning_hold "$rc" $(( exit_started + 300 ))
  exit "$rc"
}
trap recover_on_exit EXIT
trap 'exit 75' HUP
trap 'exit 130' INT
trap 'exit 75' TERM

acquire_engine_lock() {
  local label="$1" remaining wait_seconds
  remaining="$(remaining_seconds)" || die "deadline expired before $label"
  wait_seconds="$remaining"
  [ "$wait_seconds" -le 600 ] || wait_seconds=600
  exec 9>"$ENGINE_LOCK"
  legacy_entry_read flock -w "$wait_seconds" 9 || die "could not acquire the engine mutation lock for $label"
  LOCK_HELD=1
}

release_engine_lock() {
  [ "$LOCK_HELD" = 1 ] || return 0
  flock -u 9
  LOCK_HELD=0
}

# Whole-hour arithmetic only: the break opens on a fixed minute of every hour
# and runs to the top of the next one, so the answer never depends on the local
# timezone or on the engine being reachable. Zero means a break is open NOW -
# the wrap-around reading it replaced said the next break was an hour away at
# :56, which is inside the break this transaction is trying to use.
# Temporary hourly authority is immutable source, never a force input. A cycle
# is global in the canonical seal and remains bound across request/invocation
# retries. This function is called only while holding the existing engine lock.
PHASE1_POLICY_OWNED=0
PHASE1_CYCLE_START=0
PHASE1_CYCLE_END=0
PHASE1_WINDOW_START=0
PHASE1_WINDOW_END=0
phase1_custody_admission() {
  local predecessor
  predecessor="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 10s "$RELEASE_SEAL" get desired-sha)"     || die 'Phase1 sealed predecessor identity is unreadable'
  if [ "$predecessor" = "$CHECKPOINT_EED_SHA" ]; then
    legacy_census_fits || die 'Phase1 requires the full retained-owner checkpoint; census fit false or unknown before cycle reservation'
  fi
}

initialise_phase1_cycle() {
  [ "$LOCK_HELD" = 1 ] || die 'routine cycle requires the existing engine lock'
  local prior_cycle
  prior_cycle="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 15s "$RELEASE_SEAL" check-routine-owner --run-id "$RUN_ID")" \
    || die 'a prior routine cycle owner remains unresolved'
  local policy active cycle fields status owner
  timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" cat-file -e "$SHA^{commit}" || die 'routine policy target is unreadable'
  if ! timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" cat-file -e "$SHA:server/src/maintenance/maintenanceSchedulePolicy.json" 2>/dev/null; then
    return 0 # Historical source has the unchanged daily baseline.
  fi
  policy="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 15s "$RELEASE_SEAL" schedule-policy --repo "$REPO_DIR" --sha "$SHA")" \
    || die 'routine source policy is invalid'
  active="$(printf '%s' "$policy" | python3 -c 'import json,sys; print(json.load(sys.stdin)["phase1Status"])')"
  case "$active" in active|complete|off) ;; *) die 'routine policy status is invalid' ;; esac
  PHASE1_POLICY_OWNED=1; export PHASE1_POLICY_OWNED
  local foreign foreign_rc
  if foreign="$(newer_release_in_flight any)"; then
    die "routine cycle cannot compete with active runtime owner ${foreign%% *}"
  else
    foreign_rc=$?
    [ "$foreign_rc" = 1 ] || die 'foreign runtime ownership is unreadable'
  fi
  phase1_custody_admission
  if [ "$prior_cycle" = none ]; then
    local fresh_health cause
    fresh_health="$(legacy_entry_read curl -sS --max-time 5 http://127.0.0.1:8080/health)" || fresh_health='{}'
    cause="$(recovery_window_reason "$fresh_health")"
    if [ "${cause%% *}" = engine-degraded ]; then
      # Preserve the pre-existing measured-emergency contract. This is not a
      # scheduled same-SHA reset and cannot bypass a prior routine owner.
      legacy_entry_read timeout --signal=TERM --kill-after=1s 15s "$RELEASE_SEAL" current-cycle-policy \
        --repo "$REPO_DIR" --sha "$SHA" --control-sha "$CONTROL_SHA" >/dev/null \
        || die 'measured recovery source policy changed'
      return 0
    fi
  fi
  cycle="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 15s "$RELEASE_SEAL" reserve-routine-cycle --repo "$REPO_DIR" --sha "$SHA" --control-sha "$CONTROL_SHA" --run-id "$RUN_ID")" \
    || die 'routine cycle admission refused or unknown'
  if [ "$(printf '%s' "$cycle" | python3 -c 'import json,sys; print(json.load(sys.stdin)["status"])')" = daily ]; then
    PHASE1_CYCLE_START=0; PHASE1_CYCLE_END=0; PHASE1_WINDOW_START=0; PHASE1_WINDOW_END=0
    export PHASE1_CYCLE_START PHASE1_CYCLE_END PHASE1_WINDOW_START PHASE1_WINDOW_END
    return 0
  fi
  fields="$(printf '%s' "$cycle" | python3 -c 'import json,sys; c=json.load(sys.stdin); w=c.get("window") or {}; print(c["status"],c["runId"],c["startsAt"],c["endsAt"],w.get("startsAt",0),w.get("endsAt",0))')"
  read -r status owner PHASE1_CYCLE_START PHASE1_CYCLE_END PHASE1_WINDOW_START PHASE1_WINDOW_END <<<"$fields"
  if [ "$owner" != "$RUN_ID" ]; then
    die "routine cycle already belongs to run $owner ($status); no duplicate reset"
  fi
  case "$status" in
    reserved) ;;
    committed|sealed) PHASE1_CYCLE_START=0; PHASE1_CYCLE_END=0 ;; # Original canonical replay.
    *) die 'this routine cycle has a terminal refusal; no replay' ;;
  esac
  export PHASE1_CYCLE_START PHASE1_CYCLE_END PHASE1_WINDOW_START PHASE1_WINDOW_END
}

phase1_reset_required() {
  [ "${PHASE1_CYCLE_START:-0}" -gt 0 ] || return 1
  initialise_phase1_cycle
  [ "${PHASE1_CYCLE_START:-0}" -gt 0 ] || return 1
  local cycle_limit="${PHASE1_WINDOW_END:-0}"
  [ "$cycle_limit" -gt 0 ] || cycle_limit=$(((PHASE1_CYCLE_START+360)*1000))
  [ "$(date +%s%3N)" -lt "$cycle_limit" ] || die 'original routine cycle expired; no later cycle is authorized'
  return 0
}

bind_phase1_window() {
  [ "${PHASE1_CYCLE_START:-0}" -gt 0 ] || return 0
  local body="$1" took=0 rc=0 bound
  # No engine-lock traffic for idle/unrelated health. Only this cycle's actual
  # announced00minute may enter the durable compare-and-swap below.
  if ! printf '%s' "$body" | PHASE1_CYCLE_START="$PHASE1_CYCLE_START" python3 -c '
import json,os,sys
try:
 h=json.load(sys.stdin); m=h.get("maintenance") or {}; p=m.get("presentation") or {}
 stamp=p.get("break_id"); cycle=int(os.environ["PHASE1_CYCLE_START"])
 ok=m.get("active") is True and m.get("phase") in ("last_hand","counting_down") and type(stamp) is int and cycle*1000 <= stamp+120000 < (cycle+60)*1000
except Exception: ok=False
raise SystemExit(0 if ok else 1)'; then return 1; fi
  if [ "$LOCK_HELD" != 1 ]; then acquire_engine_lock 'routine window binding'; took=1; fi
  source_target_is_current
  bound="$(printf '%s' "$body" | legacy_entry_read timeout --signal=TERM --kill-after=1s 15s     "$RELEASE_SEAL" bind-routine-window --repo "$REPO_DIR" --run-id "$RUN_ID")" || rc=$?
  if [ "$took" = 1 ]; then release_engine_lock; fi
  [ "$rc" = 0 ] || return "$rc"
  read -r PHASE1_WINDOW_START PHASE1_WINDOW_END <<<"$(printf '%s' "$bound" | python3 -c 'import json,sys; w=json.load(sys.stdin)["window"]; print(w["startsAt"],w["endsAt"])')"
  export PHASE1_WINDOW_START PHASE1_WINDOW_END
}

seconds_to_next_break() {
  python3 - <<'DAILY'
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import os
now = datetime.now(timezone.utc)
local = now.astimezone(ZoneInfo('America/Chicago'))
cycle = int(os.environ.get('PHASE1_CYCLE_START', '0'))
if cycle:
    print(max(0, int(cycle-now.timestamp())))
    raise SystemExit(0)
start = local.replace(hour=4, minute=0, second=0, microsecond=0)
if start <= local < start + timedelta(minutes=5):
    print(0)
else:
    if local >= start: start += timedelta(days=1)
    print(max(0, int((start.astimezone(timezone.utc)-now).total_seconds())))
DAILY
}

source_target_is_current() {
  local main_sha latest remaining lock_wait fetch_wait attempt fetched source_deadline
  local high_water high_water_contained target_already_sealed_past
  # `local-main`: prove against the protected-main ref this transaction already
  # fetched under the engine lock before cutover, without a network fetch.
  # Every proof below still runs. See the post-cutover call for why.
  local use_local_main=0
  [ "${1:-}" != local-main ] || use_local_main=1
  remaining="$(remaining_seconds)" || die 'deadline expired before protected-main verification'
  source_deadline="$DEADLINE"
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    local proof_remaining
    proof_remaining="$(break_proof_seconds)" \
      || die 'maintenance break proof budget expired before protected-main verification'
    [ "$remaining" -le "$proof_remaining" ] || remaining="$proof_remaining"
    source_deadline=$(( $(date +%s) + remaining ))
  fi
  lock_wait="$remaining"
  [ "$lock_wait" -le 90 ] || lock_wait=90
  exec 8>"$SOURCE_LOCK"
  legacy_entry_read flock -w "$lock_wait" 8 || die 'could not acquire the source-object lock'
  fetched=0
  [ "$use_local_main" = 0 ] || fetched=1
  for attempt in 1 2 3; do
    [ "$fetched" = 0 ] || break
    remaining=$((source_deadline - $(date +%s)))
    [ "$remaining" -gt 6 ] || die 'source verification deadline expired before protected-main fetch'
    fetch_wait=$((remaining - 5))
    [ "$fetch_wait" -le 20 ] || fetch_wait=20
    if GIT_NO_REPLACE_OBJECTS=1 GIT_HTTP_LOW_SPEED_LIMIT=1024 GIT_HTTP_LOW_SPEED_TIME=15 \
      legacy_entry_read timeout --signal=TERM --kill-after=5s "${fetch_wait}s" \
      git -C "$REPO_DIR" fetch --no-tags origin '+refs/heads/main:refs/remotes/origin/main'; then
      fetched=1
      break
    fi
    if [ "$attempt" != 3 ]; then
      remaining=$((source_deadline - $(date +%s)))
      [ "$remaining" -gt 3 ] || die 'source verification deadline expired between fetch attempts'
      legacy_entry_read sleep 3
    fi
  done
  [ "$fetched" = 1 ] || die 'bounded protected-main fetch failed after three attempts'
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before protected-main inspection'
  [ "$remaining" -le 10 ] || remaining=10
  main_sha="$(legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" rev-parse --verify 'origin/main^{commit}')" \
    || die 'bounded protected-main revision lookup failed'
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before target object proof'
  [ "$remaining" -le 10 ] || remaining=10
  legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" cat-file -e "$SHA^{commit}" \
    || die 'bounded target object proof failed'
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before ancestry proof'
  [ "$remaining" -le 10 ] || remaining=10
  legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" merge-base --is-ancestor "$SHA" "$main_sha" \
    || die "target $SHA is no longer contained in protected main"
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before component high-water lookup'
  [ "$remaining" -le 10 ] || remaining=10
  latest="$(legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" log "$main_sha" -1 --format=%H -- \
      'server/**' ':(exclude)server/**/*.test.ts' ':(exclude)server/sim/**')" \
    || die 'bounded engine component high-water lookup failed'
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before server tree lookup'
  [ "$remaining" -le 10 ] || remaining=10
  EXPECTED_SERVER_TREE="$(legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env \
    GIT_NO_REPLACE_OBJECTS=1 git -C "$REPO_DIR" rev-parse --verify "$SHA:server")" \
    || die 'bounded target server tree lookup failed'
  # A normal deploy must contain the durable high-water release, including
  # after an intentional rollback moved desired-sha backwards. New protected-main
  # merges do not revoke an otherwise forward target. The engine-lock rechecks
  # and seal prepare repeat this ordering proof before any cutover can commit.
  remaining=$((source_deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || die 'source verification deadline expired before forward-only proof'
  [ "$remaining" -le 10 ] || remaining=10
  high_water="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 5s "$RELEASE_SEAL" get high-water-sha 2>/dev/null || true)"
  high_water_contained=0
  target_already_sealed_past=0
  if [[ "$high_water" =~ ^[0-9a-f]{40}$ ]]; then
    if legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
      git -C "$REPO_DIR" merge-base --is-ancestor "$high_water" "$SHA" 2>/dev/null; then
      high_water_contained=1
    else
      # A NEWER RELEASE ALREADY CARRIES THIS ONE (2026-09-26). Two exact-SHA
      # requests run side by side (the workflow's concurrency group is per
      # SHA), so the newer one can seal first. The older one then finds a
      # high-water it does not contain - and it never will, because the sealed
      # release is its descendant. That is a stand-down, not a broken build:
      # run 36216296821 (target 31ee0764, sealed high-water f1d956c3) said
      # "does not contain the sealed high-water release" and its receipt read
      # "the durable Hetzner release transaction did not complete", because
      # the workflow's classifier (classify_release_failure) only recognises
      # "is stale; protected main requires <sha>", a phrase nothing had printed
      # since #4539. The refusal is unchanged - it still dies, before any
      # mutation, with status 1 - only its words are the ones the classifier
      # and check-engine-deploy-starvation.mjs read as "stood down".
      remaining=$((source_deadline - $(date +%s)))
      if [ "$remaining" -gt 2 ]; then
        [ "$remaining" -le 10 ] || remaining=10
        if legacy_entry_read timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
          git -C "$REPO_DIR" merge-base --is-ancestor "$SHA" "$high_water" 2>/dev/null; then
          target_already_sealed_past=1
        fi
      fi
    fi
  fi
  # A rollback drill is the one target that is OLDER than the high-water by
  # design; it is admitted by its own stricter rule, still under this lock and
  # after the same protected-main containment and object proofs above.
  if [ "${DRILL_MODE:-}" = rollback ]; then
    drill_rollback_admission "$high_water" "$source_deadline"
    flock -u 8
    return 0
  fi
  flock -u 8
  [[ "$latest" =~ ^[0-9a-f]{40}$ ]] || die 'latest engine component SHA is unreadable'
  [[ "$EXPECTED_SERVER_TREE" =~ ^[0-9a-f]{40}$ ]] || die 'target server tree is unreadable'
  [[ "$high_water" =~ ^[0-9a-f]{40}$ ]] \
    || die "target $SHA cannot prove the sealed high-water release"
  if [ "$high_water_contained" != 1 ] && [ "$target_already_sealed_past" = 1 ]; then
    die "target $SHA does not contain the sealed high-water release $high_water, which already contains it: target $SHA is stale; protected main requires $high_water (stood down before mutation)"
  fi
  [ "$high_water_contained" = 1 ] \
    || die "target $SHA does not contain the sealed high-water release $high_water"
  SUPERSEDED_BY=''
  if [ "$latest" != "$SHA" ]; then
    SUPERSEDED_BY="$latest"
    echo "ENGINE_RELEASE_SUPERSEDED_BY=$latest"
    echo "[engine-release-transaction] FORWARD TARGET BEHIND MAIN: latest engine $latest; target $SHA contains sealed high-water $high_water. The maintenance certificate and every cutover proof remain mandatory." >&2
  fi
}

parse_health_instance_for_sha() {
  local expected_sha="$1"
  EXPECTED_SHA="$expected_sha" python3 -c '
import json, os, re, sys
d=json.load(sys.stdin)
instance=d.get("instanceId")
ok=(d.get("running") is True and d.get("releaseSha")==os.environ["EXPECTED_SHA"] and d.get("liveness")=="ok" and isinstance(instance,str) and re.fullmatch(r"[1-9][0-9]*-[0-9a-f]{8}",instance))
if not ok: raise SystemExit(1)
print(instance)
' 2>/dev/null
}

health_instance_for_sha() {
  local url="$1" expected_sha="$2" response http_code body curl_timeout=15 proof_remaining
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    proof_remaining="$(break_proof_seconds)" || return 1
    [ "$proof_remaining" -gt 1 ] || return 1
    curl_timeout=$((proof_remaining - 1))
    [ "$curl_timeout" -le 5 ] || curl_timeout=5
  fi
  response="$(legacy_entry_read curl -sS --max-time "$curl_timeout" -H 'Cache-Control: no-cache, no-store' \
    --write-out $'\n%{http_code}' "$url" 2>/dev/null)" || return 1
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  [ "$http_code" = 200 ] || return 1
  printf '%s' "$body" | parse_health_instance_for_sha "$expected_sha"
}

parse_sealed_source_instance_for_sha() {
  EXPECTED_SHA="$1" python3 -c '
import json,os,re,sys
d=json.load(sys.stdin)
expected=os.environ["EXPECTED_SHA"]
instance=d.get("instanceId")
identity=(d.get("releaseSha")==expected) or ("releaseSha" not in d and d.get("version")==expected[:8])
ok=(d.get("running") is True and identity and d.get("liveness")=="ok" and isinstance(instance,str) and re.fullmatch(r"[1-9][0-9]*-[0-9a-f]{8}",instance))
if not ok: raise SystemExit(1)
print(instance)
' 2>/dev/null
}

source_instance_for_sha() {
  local url="$1" expected_sha="$2" response http_code body curl_timeout=15 proof_remaining
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    proof_remaining="$(break_proof_seconds)" || return 1
    [ "$proof_remaining" -gt 1 ] || return 1
    curl_timeout=$((proof_remaining - 1))
    [ "$curl_timeout" -le 5 ] || curl_timeout=5
  fi
  # The serving rollback source may be non-routing-ready because an optional
  # subsystem is the defect this release replaces. Accept only a complete 200
  # or 503 response, then prove exact process identity and liveness from the
  # common JSON body. The caller first binds the image's unique full source
  # identity to the durable seal. Only this predecessor path may read the
  # absent-field legacy version; candidate/pre-commit/final stay strict.
  response="$(legacy_entry_read curl -sS --max-time "$curl_timeout" -H 'Cache-Control: no-cache, no-store' \
    --write-out $'\n%{http_code}' "$url" 2>/dev/null)" || return 1
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in
    200|503) ;;
    *) return 1 ;;
  esac
  printf '%s' "$body" | parse_sealed_source_instance_for_sha "$expected_sha"
}

health_instance() {
  health_instance_for_sha "$1" "$SHA"
}

# THE RESTART CERTIFICATE ASKS WHETHER A HAND IS IN THE AIR (2026-09-21)
# ─────────────────────────────────────────────────────────────────────
# This used to be one line: readyForRestart AND unparkedTables == 0. That asks
# process memory "did every engine object report itself parked", and treats
# every other answer as "a hand may be in flight". They are different
# questions, and the difference froze the platform for two and a half days.
#
# Engine 8825af51 held one tournament hand permit that could never resolve
# inside that process. Measured in engine_maintenance_break_log: of the 71
# breaks that engine lived through, 70 ended with ready_for_restart_at NULL,
# unparked_at_countdown 1 every time - while thaw_ok stayed true and ~158
# tables resumed each break. The poker was fine. The RESTART was impossible,
# including the restart carrying the build that fixes the permit.
#
# So when the gate would refuse SOLELY because of an unresolved preparation,
# it now asks the database, which can tell a hand from a corpse independently
# of any bug in the engine holding it. Three things must all agree before a
# cutover is admitted, and the first two are unchanged:
#
#   1. the countdown window is real and durable, with the full budget left;
#   2. the engine own handsInFlightTotal is present and zero;
#   3. the database finds no incomplete hand snapshot written recently.
#
# That is STRICTLY STRONGER than the old line for a real in-flight hand - it
# adds two independent witnesses to it - and weaker only for a preparation
# that is provably not a hand. Unreadable is a refusal at every step.
#
# THE SAME RULE, FOR A STOPPED BANK THE PREDECESSOR CAN NEVER RELEASE
# (2026-09-25). Engine 778075b4 had 20 tournament managers quarantined after
# lease loss; their STOPPED tournament engines answered
# hasUnretiredStoppedTimeBankCustody() true for ever (root cause fixed in
# #5254, not in that build), and /health showed readyForRestart false,
# unparkedTables 154, unparkedReasons { f06_preparation_stuck: 13,
# stopped_bank_custody_unconfirmed: 154 } at every break. Every
# auto-deploy-hetzner run since 15:59 UTC waited on a certificate that could
# not open, including the one carrying the fix.
#
# stopped_bank_custody_unconfirmed is raised ONLY by a terminal tournament
# engine, which deals no hands. What a restart discards is the in-memory
# time-bank mirror of seats that already stopped; the chips live in the
# database. That is the class the legacy checkpoint guard already calls
# DISPOSED. MaintenanceBreak now bounds it and, past the bound, reports it as
# stopped_bank_custody_stuck - which STILL refuses and is NOT in the allow-list
# below (corrected 2026-09-26, #5267): on a build with #5255 a terminal engine
# persists its custody at every break announcement, so what outlives the bound
# there is a write that keeps failing, a player's bank genuinely not on disk,
# and nothing behind this script re-checks it on an ordinary cutover. The RAW
# reason stays refused from EVERY serving release. Until 2026-09-26 one exact
# predecessor SHA (778075b4, which had no bound in its build) was admitted
# past the raw reason under the database in-flight proof; that one-shot
# exception fired once, got production off 778075b4, and was removed because a
# rollback to that SHA would have re-armed a custody reason in the allow-list.
# No bank or custody reason, and no serving-release identity, may widen what
# this certificate admits (pinned by
# noServingReleaseBuysACustodyException.law.test.ts).
floor_reservation_stamp() {
  if [ -z "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then printf '0\n'; return 0; fi
  legacy_entry_read python3 "$CONTROL_DIR/engine-release-activation-floor.py" reservation     --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA"     --deadline "$MUTATION_DEADLINE_EPOCH" --run-id "$RUN_ID"     --state-root "${ENGINE_RELEASE_STATE_DIR:-/var/lib/club-arena}"
}

maintenance_certificate() {
  # The minimum break remaining is the strict MIN_BREAK_REMAINING_MS unless the
  # caller names another; the only caller that does is the read straight after
  # a legacy checkpoint, which passes LEGACY_MIN_BREAK_REMAINING_MS.
  local minimum_ms="${1:-$MIN_BREAK_REMAINING_MS}"
  local response http_code body verdict status floor_stamp
  floor_stamp=0
  if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then
    floor_stamp="$(floor_reservation_stamp)" || return 1
  fi
  # A degraded optional subsystem can correctly make /health return 503 while
  # the engine is still running and has durably parked every table for this
  # certified break. Preserve that JSON so the certificate predicates below,
  # rather than curl's HTTP-success policy, remain the restart authority.
  # Read durable weekly ownership before health: the bounded RPC must not
  # consume a certificate whose remainingMs was captured before that read.
  legacy_entry_read "$INFLIGHT_HANDS" --env-file "$ENV_FILE" --weekly-payout-only >&2 || return 1
  response="$(legacy_entry_read curl -sS --max-time 10 --write-out $'\n%{http_code}' \
    http://127.0.0.1:8080/health 2>/dev/null)" || return 1
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in
    200|503) ;;
    *) return 1 ;;
  esac
  # A positive health owner also refuses. Missing/null health is safe only
  # after the authoritative read above; it never supplies database inactivity.
  set +e
  printf '%s' "$body" | legacy_entry_read python3 -c '
import json,sys
try: d=json.load(sys.stdin)
except Exception: raise SystemExit(3)
if not isinstance(d,dict): raise SystemExit(3)
if "weeklyPayout" not in d: raise SystemExit(2)
raise SystemExit(0 if d["weeklyPayout"] is None else 1)
'
  local weekly_status=$?
  set -e
  case "$weekly_status" in
    0|2) ;;
    *) return 1 ;;
  esac
  set +e
  if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then bind_phase1_window "$body" || return 1; fi
  verdict="$(printf '%s' "$body" | MIN_BREAK_MS="$minimum_ms" STRICT_RESTART_CERTIFICATE="${DRAINED_PREDECESSOR_CUTOVER:-0}" DAILY_TRANSITION="${DAILY_TRANSITION:-0}" ACTIVATION_FLOOR_END_EPOCH="${ACTIVATION_FLOOR_END_EPOCH:-0}" ACTIVATION_FLOOR_OWNER_WINDOW="${ACTIVATION_FLOOR_OWNER_WINDOW:-}" FLOOR_ANNOUNCED_AT="$floor_stamp" legacy_entry_read python3 -c '
import json, sys
d=json.load(sys.stdin); m=d.get("maintenance")
if not isinstance(m,dict): raise SystemExit(1)
# Protect mixed-version rollout too: an older engine still opens hourly breaks.
# Routine releases may consume only the daily 04:00 Chicago certificate.
import os
from datetime import datetime
from zoneinfo import ZoneInfo
local=datetime.now(ZoneInfo("America/Chicago"))
daily=(local.hour==4 and local.minute<5)
cycle=int(os.environ.get("PHASE1_CYCLE_START", "0"))
if cycle:
    import time
    schedule=m.get("schedule")
    hourly=isinstance(schedule,dict) and schedule.get("frequency")=="phase1-hourly" and schedule.get("policyId")=="phase1-hourly-01a1944f" and schedule.get("timeZone")=="America/Chicago" and schedule.get("startHour") is None and type(schedule.get("startMinute")) is int and schedule["startMinute"]==0 and type(schedule.get("durationMs")) is int and schedule["durationMs"]==300000 and schedule.get("hourlyCashFreeze") is True
    start=int(os.environ.get("PHASE1_WINDOW_START","0")); end=int(os.environ.get("PHASE1_WINDOW_END","0"))
    daily=start>0 and start/1000 <= time.time() < end/1000 and m.get("breakEndsAt")==end and (hourly or m.get("reason")=="Deployment Recovery")
    if not daily: raise SystemExit(1)
emergency=(m.get("reason")=="Deployment Recovery")
transition=(os.environ.get("DAILY_TRANSITION")=="1" and m.get("schedule") is None and local.minute>=55 and m.get("reason")=="Scheduled Engine Maintenance")
if not daily and not emergency and not transition: raise SystemExit(1)
floor_end=int(os.environ.get("ACTIVATION_FLOOR_END_EPOCH", "0"))
if floor_end:
    import time
    now=time.time()
    if os.environ.get("ACTIVATION_FLOOR_OWNER_WINDOW"):
        stamp=int(os.environ.get("FLOOR_ANNOUNCED_AT", "0"))
        if not (stamp > 0 and stamp/1000+120 <= now < stamp/1000+420 <= floor_end
                and emergency and m.get("breakEndsAt")==stamp+420000):
            raise SystemExit(1)
    elif not (floor_end-300 <= now < floor_end and daily and m.get("reason")=="Scheduled Engine Maintenance"):
        raise SystemExit(1)
remaining=int(m.get("remainingMs") or 0)
window=(d.get("running") is True and m.get("active") is True and m.get("phase")=="counting_down" and m.get("durableConfirmed") is True)
if not window: raise SystemExit(1)
# A straggler can prevent restart certification for the entire real window.
# Record that missed opportunity separately from permission to cut over. Only
# this durable health observation qualifies; missing/unreadable health does not.
if remaining<int(__import__("os").environ["MIN_BREAK_MS"]):
    # Below the budget is not the only fact. On 2026-09-26 five breaks logged
    # only "below the 260000ms budget" while 630 stopped-custody tables held
    # the certificate shut from the first second of every countdown, and the
    # stall read as a timing fault. Name the shut certificate on stderr; the
    # verdict on stdout and the exit code are unchanged.
    if not (m.get("readyForRestart") is True and m.get("unparkedTables")==0):
        sys.stderr.write("[engine-release-transaction] the restart certificate is also shut: unparkedTables=%r unparkedReasons=%r\n" % (m.get("unparkedTables"), m.get("unparkedReasons")))
    print(remaining)
    raise SystemExit(2)
ok=(m.get("readyForRestart") is True and m.get("unparkedTables")==0)
if ok:
    print(remaining)
    raise SystemExit(0)
# NAME A SHUT CERTIFICATE WHILE IT STILL MATTERS (2026-09-27). Every refusal
# below this line used to be silent, so in the part of the break where a
# cutover could still be admitted the journal said nothing at all, and the
# first line anyone saw was "below the 260000ms budget" some 40 seconds in.
# That is how six weeks of stopped-custody refusals (630 tables, then 6) read
# as "the certificate arrives too late" (runs 36233878494, 36233889941). The
# verdict and exit codes are unchanged; this only says why, on stderr, unless
# the database admission further down actually admits.
_admitted=[False]
def _name_the_shut_certificate():
    if not _admitted[0]:
        sys.stderr.write("[engine-release-transaction] the restart certificate is shut with %dms of the break left: unparkedTables=%r unparkedReasons=%r handsInFlightTotal=%r\n" % (remaining, m.get("unparkedTables"), m.get("unparkedReasons"), d.get("handsInFlightTotal")))
__import__("atexit").register(_name_the_shut_certificate)
# A drained-boundary replacement of eed06fe5 (LEGACY_CENSUS_* above) accepts
# only the engine own open certificate. A bounded F06 preparation is a
# retained hand, not a drained boundary, so it never reaches the database
# admission below; the shut certificate is still named on stderr.
if os.environ.get("STRICT_RESTART_CERTIFICATE")=="1": raise SystemExit(1)
# ── Refusing. Is this "a hand is in the air", or "a preparation that can never
# resolve in this process"? Those are different facts and only the first is a
# reason not to restart. See the block comment above this function.
#
# The window, durability and time-remaining predicates above have all already
# passed against whichever rung of the ladder the caller named - 285000ms for
# the legacy admission, 260000ms for the ordinary one, 245000ms for both
# locked reads - where the engine itself demands 180000ms, so at this point the
# ONLY thing keeping readyForRestart shut is the
# unparked count. Nothing else is being relaxed.
#
# The BOUNDED classes: each is a blocker the engine itself has already aged
# past MaintenanceBreak.F06_UNRESOLVED_GATE_MS (or is the live half of one
# that the engine will age), raised only by a table that deals no hands.
# No bank or custody name may appear in this set (pinned by
# theCertificateOpensBeforeTheFleetIsSwept and everyRestartBlockerDeclaresItsBound).
BOUNDED_ONLY={"f06_preparation_unresolved","f06_preparation_stuck"}
unparked=m.get("unparkedTables")
if not isinstance(unparked,int) or isinstance(unparked,bool) or unparked<1: raise SystemExit(1)
reasons=m.get("unparkedReasons")
if not isinstance(reasons,dict) or not reasons: raise SystemExit(1)
# An ALLOW-list, never a deny-list: a reason string this script does not
# recognise refuses. cards_in_air, the bank-durability classes (unwritten,
# unreadable, bank_park_write_incomplete) and anything a future engine invents
# are all outside the set and all keep the gate shut.
for k,v in reasons.items():
    if not isinstance(k,str): raise SystemExit(1)
    if k not in BOUNDED_ONLY: raise SystemExit(1)
    if not isinstance(v,int) or isinstance(v,bool) or v<0: raise SystemExit(1)
# The engine own physical witness, which must be PRESENT and zero. Absent is
# unreadable, and unreadable is a refusal, never an assumed zero.
hands=d.get("handsInFlightTotal")
if not isinstance(hands,int) or isinstance(hands,bool) or hands!=0: raise SystemExit(1)
sys.stderr.write("[engine-release-transaction] restart certificate is held shut only by " + repr(reasons) + "; consulting the database for hands actually in the air\n")
_admitted[0]=True
print(remaining)
raise SystemExit(4)
')"
  status=$?
  set -e
  case "$status" in
    0) printf '%s\n' "$verdict"; return 0 ;;
    2) printf '%s\n' "$verdict"; return 2 ;;
    4) ;;
    *) return 1 ;;
  esac
  # Fail closed. Exit 0 is the ONLY result that proceeds. The helper answers 1
  # for a hand in the air and 3 for "could not tell", and both refuse here.
  # There is deliberately no flag, variable or argument that skips this.
  #
  # EVERY refusal is named separately, because on 2026-09-21 they were not.
  # The helper was absent from the installed control generation, the shell
  # answered 127, and `if ...; then` reported that as the same thing as "the
  # felt is not quiet" - so five consecutive releases said the database had
  # refused when the database had never been asked. A missing helper is
  # UNKNOWN, and UNKNOWN has to say so in its own words (CLAUDE.md 10.86
  # rules 1 and 2). All four branches still refuse; only the message differs.
  #
  # STDOUT IS THE VERDICT AND NOTHING ELSE (2026-09-26). Every caller reads
  # this function as `BREAK_REMAINING_MS="$(maintenance_certificate ...)"` and
  # then does arithmetic on it, so the ONLY bytes it may print to stdout are
  # the remaining-milliseconds figure. The helper announces its answer on
  # stdout and the admission line below used to as well; the first admission
  # that ever reached this branch (run 36211686180, 02:34:11Z, predecessor
  # 778075b4) captured "[engine-release-inflight-hands] no hand in the air ...
  # 294308" as the figure, `$(( ... / 1000 ))` refused it as a syntax error,
  # and the transaction died before prepare. Nothing had been mutated, but a
  # cutover every other gate had admitted was thrown away. Both now go to
  # stderr, where the journal still records them.
  set +e
  legacy_entry_read "$INFLIGHT_HANDS" --env-file "$ENV_FILE" >&2
  local inflight_rc=$?
  set -e
  case "$inflight_rc" in
    0)
      echo "[engine-release-transaction] the database confirms no hand is in the air; admitting the cutover past the unresolved preparation named above" >&2
      printf '%s\n' "$verdict"
      return 0
      ;;
    1)
      echo "[engine-release-transaction] the database says a hand IS in the air; the cutover stays refused" >&2
      ;;
    3)
      echo "[engine-release-transaction] the database could not tell whether the felt is quiet; the cutover stays refused" >&2
      ;;
    126|127)
      echo "[engine-release-transaction] UNKNOWN: $INFLIGHT_HANDS is missing from this control generation or is not executable (status $inflight_rc). The database was NEVER ASKED. This is a packaging fault in install-engine-supervisor.sh REQUIRED_FILES, not a verdict about the felt; the cutover stays refused." >&2
      ;;
    *)
      echo "[engine-release-transaction] UNKNOWN: the in-flight-hands helper exited $inflight_rc, which is not one of its three defined answers; the cutover stays refused" >&2
      ;;
  esac
  return 1
}

# Entry to the exact predecessor's checkpoint, NOT restart authority. Its old
# unparked count combines physical hands with missing bank durability, and its
# saved-bank bit can remain true after the final announced write erased a row.
# The helper independently checks every physical table before writing. Only
# the unchanged maintenance_certificate below can admit a replacement.
legacy_checkpoint_countdown() {
  local response http_code body headroom floor_stamp elapsed_ms=0 expected_end="${2:-0}"
  floor_stamp=0
  if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then
    floor_stamp="$(floor_reservation_stamp)" || return 1
  fi
  # Required headroom for the entry work that still has to happen AFTER this
  # admission and BEFORE the guard reads the same reserve. Defaulting to 0
  # keeps the historical contract for callers that have nothing left to do.
  headroom="${1:-0}"
  if [ "${3:-initial}" = locked ]; then
    elapsed_ms=$(( $(date +%s%3N) - ENTRY_STARTED_MS ))
    [ "$elapsed_ms" -ge 0 ] && [ "$elapsed_ms" -lt 35000 ] || return 1
    [ "$expected_end" -gt 0 ] || return 1
  fi
  # Read durable weekly ownership before health: the bounded RPC must not
  # consume a certificate whose remainingMs was captured before that read.
  legacy_entry_read "$INFLIGHT_HANDS" --env-file "$ENV_FILE" --weekly-payout-only >&2 || return 1
  response="$(legacy_entry_read curl -sS --max-time 2 --write-out $'\n%{http_code}' \
    http://127.0.0.1:8080/health 2>/dev/null)" || return 1
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in 200|503) ;; *) return 1 ;; esac
  # A positive health owner also refuses. Missing/null health is safe only
  # after the authoritative read above; it never supplies database inactivity.
  set +e
  printf '%s' "$body" | legacy_entry_read python3 -c '
import json,sys
try: d=json.load(sys.stdin)
except Exception: raise SystemExit(3)
if not isinstance(d,dict): raise SystemExit(3)
if "weeklyPayout" not in d: raise SystemExit(2)
raise SystemExit(0 if d["weeklyPayout"] is None else 1)
'
  local weekly_status=$?
  set -e
  case "$weekly_status" in
    0|2) ;;
    *) return 1 ;;
  esac
  printf '%s' "$body" | MIN_BREAK_MS=$((MIN_BREAK_REMAINING_MS + headroom)) ENTRY_STARTED_MS="${ENTRY_STARTED_MS:-0}" ENTRY_MODE="${3:-initial}" EXPECTED_BREAK_END_EPOCH="$expected_end" DAILY_TRANSITION="${DAILY_TRANSITION:-0}" ACTIVATION_FLOOR_END_EPOCH="${ACTIVATION_FLOOR_END_EPOCH:-0}" ACTIVATION_FLOOR_OWNER_WINDOW="${ACTIVATION_FLOOR_OWNER_WINDOW:-}" FLOOR_ANNOUNCED_AT="$floor_stamp" legacy_entry_read python3 -c '
import json, math, os, sys, time
d=json.load(sys.stdin); m=d.get("maintenance")
if not isinstance(m,dict): raise SystemExit(1)
# Protect mixed-version rollout too: an older engine still opens hourly breaks.
# Routine releases may consume only the daily 04:00 Chicago certificate.
import os
from datetime import datetime
from zoneinfo import ZoneInfo
local=datetime.now(ZoneInfo("America/Chicago"))
daily=(local.hour==4 and local.minute<5)
cycle=int(os.environ.get("PHASE1_CYCLE_START", "0"))
if cycle:
    import time
    schedule=m.get("schedule")
    hourly=isinstance(schedule,dict) and schedule.get("frequency")=="phase1-hourly" and schedule.get("policyId")=="phase1-hourly-01a1944f" and schedule.get("timeZone")=="America/Chicago" and schedule.get("startHour") is None and type(schedule.get("startMinute")) is int and schedule["startMinute"]==0 and type(schedule.get("durationMs")) is int and schedule["durationMs"]==300000 and schedule.get("hourlyCashFreeze") is True
    start=int(os.environ.get("PHASE1_WINDOW_START","0")); end=int(os.environ.get("PHASE1_WINDOW_END","0"))
    daily=start>0 and start/1000 <= time.time() < end/1000 and m.get("breakEndsAt")==end and (hourly or m.get("reason")=="Deployment Recovery")
    if not daily: raise SystemExit(1)
emergency=(m.get("reason")=="Deployment Recovery")
transition=(os.environ.get("DAILY_TRANSITION")=="1" and m.get("schedule") is None and local.minute>=55 and m.get("reason")=="Scheduled Engine Maintenance")
if not daily and not emergency and not transition: raise SystemExit(1)
floor_end=int(os.environ.get("ACTIVATION_FLOOR_END_EPOCH", "0"))
if floor_end:
    import time
    now=time.time()
    if os.environ.get("ACTIVATION_FLOOR_OWNER_WINDOW"):
        stamp=int(os.environ.get("FLOOR_ANNOUNCED_AT", "0"))
        if not (stamp > 0 and stamp/1000+120 <= now < stamp/1000+420 <= floor_end
                and emergency and m.get("breakEndsAt")==stamp+420000):
            raise SystemExit(1)
    elif not (floor_end-300 <= now < floor_end and daily and m.get("reason")=="Scheduled Engine Maintenance"):
        raise SystemExit(1)

remaining=m.get("remainingMs"); ends=m.get("breakEndsAt")
valid_number=lambda n: isinstance(n,(int,float)) and not isinstance(n,bool) and math.isfinite(n)
if not (d.get("running") is True and m.get("active") is True and m.get("phase")=="counting_down" and m.get("durableConfirmed") is True and valid_number(remaining) and valid_number(ends)):
    raise SystemExit(1)
minimum=int(os.environ["MIN_BREAK_MS"])
if os.environ["ENTRY_MODE"]=="locked":
    spent=math.floor(time.time()*1000)-int(os.environ["ENTRY_STARTED_MS"])
    if not 0<=spent<35000: raise SystemExit(1)
    minimum-=spent
expected=int(os.environ["EXPECTED_BREAK_END_EPOCH"])
if expected and math.floor(ends/1000)!=expected:
    raise SystemExit(1)
if remaining<minimum or ends-time.time()*1000<minimum:
    raise SystemExit(1)
print(math.floor(ends/1000))
' 2>/dev/null
}

# This is one optional event in the existing bounded transaction, not a
# background retry owner. The immutable seal reservation survives SSH loss,
# systemd retries and unknown HTTP outcomes without sliding the break end.
#
# AN OFF-CYCLE WINDOW IS PROPORTIONATE, NOT ONE PER MERGE (2026-09-26)
# ───────────────────────────────────────────────────────────────────
# Measured in engine_maintenance_break_log on 2026-09-25/26: 4-5 breaks in a
# busy hour and 29-36 minutes of the hour with every table parked, hands/min
# down from ~550 to ~200. The autopilot merges all day and every merge's
# release asked for its own "Deployment Recovery" window. The host journal
# shows how: when N releases wait through one break, the first admission
# ships and every other one reads the rest of that break as
# CERTIFICATE_RC=2 ("below the 260000ms budget", down to "0ms remaining"
# after it ends). That set RECOVERY_ADMISSION_MISSED=1 for all of them, and
# at :03 each asked for its own window - which again only one of them could
# use. On 2026-09-26 902565dd, 94c7cf0b, 1cb373d1 and 6cd35918 were in
# flight together and paused the floor at 05:55, 06:05 and 06:1x for one
# release each.
#
# The escape hatch stays (it is what got fixes out of the 09-18..09-25
# outage). What changes is WHEN a release may spend it, never what makes a
# cutover safe - maintenance_certificate, the ladder, the rollback reserve,
# the database witness and the locked read are untouched:
#
#   1. A measured engine emergency is required. Ordinary releases wait for
#      04:00 America/Chicago. Commit text (including an urgent trailer), a
#      missed window and a request deadline never authorize a global pause.
#      Only current liveness=dead, wholeFleetStalled or at least
#      RECOVERY_QUARANTINED_MANAGERS quarantined managers may ask the seal.
#   2. The newest release owns the window: a release never asks while a
#      release of a newer protected-main engine SHA is queued or running on
#      this host.
#   3. At most one off-cycle window per rolling hour across every release.
#      The seal enforces it under its own lock from the durable per-run
#      reservation files, so it holds across processes, retries and control
#      generations.
RECOVERY_REQUESTED=0
RECOVERY_CHECKED_CAUSE=-1
RECOVERY_ADMISSION_MISSED=0
RECOVERY_NEXT_EVALUATION=0
RECOVERY_DEFER_SECONDS=60
RECOVERY_DEFERRED_TO=''
BREAK_DEFERRED_TO=''
RECOVERY_REFUSED_STUCK=0
# A missed restart certificate is history, not evidence that a dealing engine
# is dead, stalled or wedged. It must never authorize an extra platform break.
# Calibrated on production, 2026-09-26: 209d1b45 dealt normally (liveness ok,
# certificate opening at :55) with 16-27 managers quarantined after
# tournament_lease_lost_stop_failed, and the first release to read 16 as
# "degraded" spent the 07:37Z window on it and shipped nothing. The 04:45Z
# wedge that took hands/min to ~0 (#5298) quarantined 338. A quarantine count
# is only a reason to pause every table when it is wedge-sized.
RECOVERY_QUARANTINED_MANAGERS=100

# A certificate this release could not use counts as a missed scheduled
# break only when the release was already waiting while that break could
# still admit it: its first (BREAK_WINDOW_MS - BREAK_ADMISSION_MIN_BREAK_MS)
# of countdown. A release whose build finished at :57 arrived late; that is
# not the break failing, and it waits for the next one.
# Since 2026-10-04 a missed break is recorded only: it is not a reason for an
# off-cycle window (recovery_window_reason never names it).
note_missed_admission() {
  local remaining_ms="${1:-0}" now break_started
  [[ "$remaining_ms" =~ ^[0-9]+$ ]] && [ "$remaining_ms" -gt 0 ] || return 0
  now="$(date +%s)"
  break_started=$(( now + remaining_ms / 1000 - BREAK_WINDOW_MS / 1000 ))
  if [ "${RECOVERY_WAIT_STARTED_EPOCH:-0}" -le \
    $(( break_started + (BREAK_WINDOW_MS - BREAK_ADMISSION_MIN_BREAK_MS) / 1000 )) ]; then
    RECOVERY_ADMISSION_MISSED=1
  fi
}

# Prints "<class> <detail>" for the first reason that applies, or nothing.
recovery_window_reason() {
  local health="$1" degraded now past next_break last_admission
  if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
    now="$(date +%s)"
    if [ "$now" -ge $((PHASE1_CYCLE_START - 120)) ] && [ "$now" -lt $((PHASE1_CYCLE_START - 60)) ]; then
      # First adoption only: a running old daily engine cannot announce00.
      # Its existing durable recovery door consumes this one fixed58 timestamp.
      if printf '%s' "$health" | python3 -c '
import json,sys
h=json.load(sys.stdin); m=h.get("maintenance") or {}; s=m.get("schedule") or {}
raise SystemExit(0 if h.get("running") is True and s.get("frequency")!="phase1-hourly" and m.get("recoveryWindowProtocol")=="engine-recovery-window-v1" else 1)'; then
        echo phase1-hourly
        return 0
      fi
    fi
  fi
  [ "${PHASE1_CYCLE_START:-0}" = 0 ] || return 0
  degraded="$(printf '%s' "$health" | python3 -c '
import json, sys
d = json.load(sys.stdin)
count = lambda v: v if isinstance(v, int) and not isinstance(v, bool) else 0
signs = []
if d.get("liveness") == "dead": signs.append("liveness=dead")
if d.get("wholeFleetStalled") is True: signs.append("wholeFleetStalled")
if count(d.get("tournamentManagersQuarantined")) >= int(sys.argv[1]):
    signs.append("tournamentManagersQuarantined=%d" % d["tournamentManagersQuarantined"])
print(",".join(signs))
' "$RECOVERY_QUARANTINED_MANAGERS" 2>/dev/null)" || degraded=''
  if [ -n "$degraded" ]; then
    echo "engine-degraded $degraded"
    return 0
  fi
  # A routine request's expiry is never an emergency. It waits for the next
  # daily producer invocation rather than manufacturing a daytime freeze.
  return 0
}

# OWNER-ORDERED WINDOW (2026-10-23)
# ───────────────────────────────────
# The 04:00 America/Chicago rule stays binding "absent a later explicit narrow
# human exception" (#7777). This is that exception's only carrier: an entry in
# server/release/owner-maintenance-windows.json, merged through protected main,
# that quotes the owner's order and names the exact commit that must be inside
# the release, a bounded validity window (at most six hours) and the Chicago
# minutes at which the announcement may be made. Commit text is still never
# authority. The entry is read from the TARGET's own immutable tree, so it
# cannot be granted by anything other than reviewed source, and it expires on
# its own. Everything after the reason is unchanged: newest-owner, lock, a
# fresh health read, the seal's one-window-per-hour limit, drain, freeze,
# certificate, rollback reserve and thaw.
# Prints "owner-ordered <id>" or nothing; never fails the caller.
owner_window_reason() {
  local windows now picked id contains serving witness_path witness_sha target_witness served_witness engine_uptime
  windows="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" show "$SHA:server/release/owner-maintenance-windows.json" 2>/dev/null)" || return 0
  now="$(date +%s)"
  # The serving process's own uptime, for a window that may only open right
  # after an engine start (withinSecondsOfEngineStart). Unreadable is "".
  engine_uptime="$(printf '%s' "${1:-}" | python3 -c '
import json, sys
try: v = json.load(sys.stdin).get("uptime")
except Exception: v = None
print(v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else "")
' 2>/dev/null)" || engine_uptime=''
  picked="$(printf '%s' "$windows" | python3 -c '
import json, re, sys
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
now = datetime.fromtimestamp(int(sys.argv[1]), timezone.utc)
local = now.astimezone(ZoneInfo("America/Chicago"))
doc = json.load(sys.stdin)
if not isinstance(doc, dict) or doc.get("version") != 1: raise SystemExit(0)
entries = [w for w in doc.get("windows") or [] if isinstance(w, dict)]
# Prefer specific feature orders, preserving order within each class. Known
# consumed witnesses may fall back to the original first legacy window.
entries = [w for w in entries if "releaseWitness" in w] + [w for w in entries if "releaseWitness" not in w]
import os
selected = os.environ.get("ACTIVATION_FLOOR_OWNER_WINDOW", "")
if selected: entries = [w for w in entries if w.get("id") == selected]
for w in entries:
    try:
        wid, contains, order = str(w["id"]), str(w["contains"]), str(w["ownerOrder"])
        nb = datetime.fromisoformat(str(w["notBefore"]).replace("Z", "+00:00"))
        na = datetime.fromisoformat(str(w["notAfter"]).replace("Z", "+00:00"))
        minutes = w.get("announceAtChicagoMinutes")
    except Exception:
        continue
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,63}", wid): continue
    if not re.fullmatch(r"[0-9a-f]{40}", contains) or len(order.strip()) < 10: continue
    if nb.tzinfo is None or na.tzinfo is None: continue
    if not (0 < (na - nb).total_seconds() <= 6 * 3600) or not (nb <= now <= na): continue
    if minutes is not None and (not isinstance(minutes, list) or local.minute not in minutes): continue
    # FRESH-ENGINE WINDOW (2026-11-01). eed06fe5 restarts on its own every
    # 90-120 minutes; within minutes of a start it has re-adopted almost none of
    # the tables it can never finish and its heap is small enough for the
    # census, so the unchanged certificate and census can both pass. A window
    # carrying this field grants its reason only while the serving process is
    # at most that many seconds old; an unreadable uptime grants nothing.
    fresh = w.get("withinSecondsOfEngineStart")
    if fresh is not None:
        if not (isinstance(fresh, int) and not isinstance(fresh, bool) and 30 <= fresh <= 600): continue
        if not re.fullmatch(r"[0-9]+", sys.argv[2]) or int(sys.argv[2]) > fresh: continue
    witness = w.get("releaseWitness")
    path, digest = "-", "-"
    if "releaseWitness" in w:
        valid = isinstance(witness, dict) and set(witness) == {"path", "sha256"}
        if valid: path, digest = witness["path"], witness["sha256"]
        if not (valid and isinstance(path, str) and (re.fullmatch(r"supabase/migrations/[0-9]{14}_[a-z0-9_]+\.sql", path) or path == "server/scripts/retained-original-checkpoint-guard.mjs" or (selected == wid and path == "server/release/activation-floor.json"))
                and isinstance(digest, str) and re.fullmatch(r"[0-9a-f]{64}", digest)):
            print("invalid - - -")
            break
    print(wid, contains, path, digest)
' "$now" "$engine_uptime" 2>/dev/null)" || return 0
  [ -n "$picked" ] || return 0
  while read -r id contains witness_path witness_sha; do
  timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" merge-base --is-ancestor "$contains" "$SHA" 2>/dev/null || return 0
  # ONCE (2026-10-23): the order is "make this commit live". When the serving
  # engine already contains it, the window grants nothing more, so later
  # merges inside the window never earn another reset. An unreadable serving
  # identity grants nothing either.
  serving="$(printf '%s' "${1:-}" | python3 -c '
import json, re, sys
v = json.load(sys.stdin).get("releaseSha")
print(v if isinstance(v, str) and re.fullmatch(r"[0-9a-f]{40}", v) else "")
' 2>/dev/null)" || return 0
  [ -n "$serving" ] || return 0
  if [ "$witness_path" != '-' ]; then
    # An immutable feature witness cannot be consumed by an unrelated release
    # of the shared base. Full serving history prevents replay after deletion.
    [ "$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
      git -C "$REPO_DIR" rev-parse --is-shallow-repository 2>/dev/null)" = false ] || return 0
    target_witness="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
      git -C "$REPO_DIR" show "$SHA:$witness_path" 2>/dev/null \
      | python3 -c 'import hashlib,sys; print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())')" || return 0
    [ "$target_witness" = "$witness_sha" ] || return 0
    if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ] && [ "$witness_path" = server/release/activation-floor.json ]; then
      local witness_blob
      witness_blob="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 git -C "$REPO_DIR" rev-parse "$SHA:$witness_path")" || return 0
      served_witness="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 git -C "$REPO_DIR" log -1 --format=%H --find-object="$witness_blob" "$serving" -- "$witness_path")" || return 0
    else
      served_witness="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 git -C "$REPO_DIR" rev-list -1 "$serving" -- "$witness_path" 2>/dev/null)" || return 0
    fi
    [ -z "$served_witness" ] || continue
  elif timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" merge-base --is-ancestor "$contains" "$serving" 2>/dev/null; then
    return 0
  fi
  echo "owner-ordered $id"
  return 0
  done <<< "$picked"
}

# The seal and the serving engine already know one explicit owner cause,
# `urgent`; an owner-ordered window is presented to both as that cause.
recovery_cause() {
  case "$1" in
    owner-ordered|phase1-hourly) echo urgent ;;
    *) echo "$1" ;;
  esac
}

# The run key and SHA of a release of a NEWER engine SHA that is queued or
# running on this host, if there is one. Only a durable request whose unit is
# still live counts; a finished or failed one owns nothing.
newer_release_in_flight() {
  local request run other state mode="${1:-newer}"
  for request in "$REQUEST_ROOT"/*.request; do
    [ -f "$request" ] || continue
    run="${request##*/}"
    run="${run%.request}"
    [ "$run" != "$RUN_ID" ] || continue
    other="$(head -n 1 -- "$request" 2>/dev/null)" || continue
    if [ "$mode" = any ]; then
      [[ "$other" =~ ^[0-9a-f]{40}$ ]] || return 2
    else
      [[ "$other" =~ ^[0-9a-f]{40}$ ]] && [ "$other" != "$SHA" ] || continue
    fi
    state="$(systemctl show "club-arena-engine-release-v1@$run.service" \
      -p ActiveState --value 2>/dev/null || true)"
    case "$state" in active|activating|reloading) ;;
      deactivating) [ "$mode" = any ] || continue ;;
      inactive|failed) continue ;;
      *) [ "$mode" != any ] || return 2; continue ;;
    esac
    if [ "$mode" != any ]; then
    timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
      git -C "$REPO_DIR" merge-base --is-ancestor "$SHA" "$other" 2>/dev/null || continue
    fi
    printf '%s %s\n' "$run" "$other"
    return 0
  done
  return 1
}

# THE NEWEST WAITING RELEASE TAKES THE BREAK (2026-09-27)
# ────────────────────────────────────────────────────────
# Measured at the 15:55Z break on 2026-09-27, the first hourly cutover since
# 2026-09-26 14:06Z: runs 36328195568 (4946473b), 36328946522 (6b6eabb1) and
# 36329422702 (c8cbe6e6) were ALL built and ALL admitted by the same
# certificate at 15:55:03-15:55:06 with ~297000ms left. The oldest happened to
# take the engine lock first and sealed 4946473b at 15:56:44. The two newer
# ones, which contain it, then read 194653ms and 193966ms under the lock -
# below the 245000ms floor - and had to wait for the next hour. So the one
# window an hour shipped the LEAST code it could have, and every fix merged
# after 4946473b (#5413's lease fix among them) stayed off production for
# another hour. With N releases queued, a lock race can cost up to N hours.
#
# A newer protected-main target contains every older one (squash merges on a
# linear main), and once it seals, the older transactions stand down on their
# own through source_target_is_current ("target ... is stale"). So an older
# target that finds a NEWER target already waiting at this same certificate -
# image built, unit live, marker naming exactly the SHA of that run's durable
# request - stands aside and keeps waiting instead of racing it for the lock.
# Nothing is relaxed: the newer release still passes every certificate, lock,
# rollback, candidate and database proof itself, and if it leaves (sealed,
# failed or rolled back) its marker leaves with it and this release is back to
# exactly the admission it had before.
newer_release_awaiting_certificate() {
  local marker run other request state
  for marker in "$REQUEST_ROOT"/*.awaiting-certificate; do
    [ -f "$marker" ] && [ ! -L "$marker" ] || continue
    run="${marker##*/}"
    run="${run%.awaiting-certificate}"
    [[ "$run" =~ ^[1-9][0-9]*(-[1-9][0-9]*)?$ ]] || continue
    [ "$run" != "$RUN_ID" ] || continue
    other="$(head -n 1 -- "$marker" 2>/dev/null)" || continue
    [[ "$other" =~ ^[0-9a-f]{40}$ ]] && [ "$other" != "$SHA" ] || continue
    # The marker may only speak for the run's own immutable request.
    request="$(head -n 1 -- "$REQUEST_ROOT/$run.request" 2>/dev/null)" || continue
    [ "$request" = "$other" ] || continue
    state="$(systemctl show "club-arena-engine-release-v1@$run.service" \
      -p ActiveState --value 2>/dev/null || true)"
    case "$state" in active|activating|reloading) ;; *) continue ;; esac
    timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
      git -C "$REPO_DIR" merge-base --is-ancestor "$SHA" "$other" 2>/dev/null || continue
    printf '%s %s\n' "$run" "$other"
    return 0
  done
  return 1
}

legacy_inspector_is_closed() {
  # An earlier unknown cleanup is not cleared by healthy gameplay HTTP.
  # Read only the fixed loopback listener; never attach, signal or close it.
  # docker exec inherits the container's Node startup options. The observer
  # must not open its own inspector or execute an application preload.
  # Reject the checkpoint's already-unsupported container options BEFORE an
  # announcement, without starting Node or returning any environment value.
  timeout --signal=TERM --kill-after=1s 3s docker exec "$CONTAINER" sh -c '
case "${NODE_OPTIONS-}" in *--inspect*|*--debug*) exit 1 ;; esac
exec env -u NODE_OPTIONS -u NODE_PATH node --no-inspect "$@"
' checkpoint-readiness -e '
const socket=require("node:net").createConnection({host:"127.0.0.1",port:9229});
socket.once("connect",()=>{socket.destroy();process.exit(1);});
socket.once("error",error=>{socket.destroy();process.exit(error.code==="ECONNREFUSED"?0:2);});
socket.setTimeout(1000,()=>{socket.destroy();process.exit(2);});
'
}

request_recovery_window() {
  local health minute now stamp outcome reason cause_key newer stuck cause_required
  local reserve_args
  [ "$RECOVERY_REQUESTED" = 0 ] || return 0
  # This immutable one-time target may use only its daily certificate.
  [ "${ACTIVATION_FLOOR_END_EPOCH:-0}" = 0 ] || [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ] || return 0
  # A drill is planned work: it waits for a scheduled break and never spends
  # the hour's one off-cycle window that a real emergency may need.
  [ -z "${DRILL_MODE:-}" ] || return 0
  now="$(date +%s)"
  # The engine owner checks overlap with the actual daily announcement.
  # Hourly tournament breaks do not restrict emergency global maintenance.
  [ "$now" -ge "$RECOVERY_NEXT_EVALUATION" ] || return 0
  health="$(curl -sS --max-time 5 http://127.0.0.1:8080/health 2>/dev/null)" || return 0
  printf '%s' "$health" | python3 -c '
import json,sys
d=json.load(sys.stdin); m=d.get("maintenance") or {}
raise SystemExit(0 if d.get("running") is True and m.get("active") is False and m.get("recoveryWindowReady") is True and m.get("recoveryWindowProtocol")=="engine-recovery-window-v1" else 1)
' || return 0
  # A WINDOW THE CERTIFICATE WILL REFUSE BUYS NOTHING (2026-09-26). The
  # certificate refuses stopped_bank_custody_stuck in every break, by design
  # and with no serving-release exception (#5288). While the engine reports
  # such tables, an off-cycle window parks every table for seven minutes and
  # cannot admit anyone, whatever the reason for asking. Measured: 209d1b45
  # reported 27 of them from 07:37Z (tournament_lease_lost_stop_failed,
  # "retained time-bank custody"), and neither the 07:37Z window nor the 07:55
  # break could open. The count is the engine's own last census; when a break
  # finds the custody cleared it drops to 0 and windows are possible again.
  stuck="$(printf '%s' "$health" | python3 -c '
import json, sys
m = json.load(sys.stdin).get("maintenance") or {}
v = m.get("stoppedCustodyStuckTables")
print(v if isinstance(v, int) and not isinstance(v, bool) and v > 0 else 0)
' 2>/dev/null)" || stuck=0
  if [ "$stuck" != 0 ]; then
    RECOVERY_NEXT_EVALUATION=$(( now + RECOVERY_DEFER_SECONDS ))
    if [ "$RECOVERY_REFUSED_STUCK" != "$stuck" ]; then
      RECOVERY_REFUSED_STUCK="$stuck"
      echo "[engine-release-transaction] the serving engine reports $stuck stopped-bank custody table(s) past their bound; the certificate refuses them in every break, so an off-cycle window would pause every table and admit nobody. Not asking."
    fi
    return 0
  fi
  if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
    reason="$(recovery_window_reason "$health")"
  elif [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then
    reason="$(owner_window_reason "$health")"
    [ "$reason" = "owner-ordered $ACTIVATION_FLOOR_OWNER_WINDOW" ] || reason=''
  else
    reason="$(recovery_window_reason "$health")"
    if [ "${PHASE1_FLOOR_SELECTED:-0}" = 0 ]; then
      [ -n "$reason" ] || reason="$(owner_window_reason "$health")"
    fi
  fi
  # NO LOCK WITHOUT AN EMERGENCY (2026-10-04). The seal answers `unavailable`
  # to every reservation that names no cause, so a routine release (no
  # reason, or only a scheduled break it waited through) has nothing to ask.
  # Taking the engine lock for that guaranteed answer contended with sibling
  # releases for up to the whole lock wait and could end this one in `die`.
  # It waits for the scheduled break without touching the lock or the seal.
  case "${reason%% *}" in
    engine-degraded|owner-ordered|phase1-hourly) ;;
    *) return 0 ;;
  esac
  cause_key="$RECOVERY_ADMISSION_MISSED:${reason%% *}"
  [ "$RECOVERY_CHECKED_CAUSE" != "$cause_key" ] || return 0
  acquire_engine_lock 'one recovery announcement'
  source_target_is_current
  if EXACT_INSTANCE="$(exact_runtime_instance)" && ! phase1_reset_required; then
    emit_already_released "$EXACT_INSTANCE"
  fi
  if [ -n "${SUPERSEDED_BY:-}" ] && newer="$(newer_release_in_flight)"; then
    release_engine_lock
    RECOVERY_NEXT_EVALUATION=$(( $(date +%s) + RECOVERY_DEFER_SECONDS ))
    if [ "$RECOVERY_DEFERRED_TO" != "$newer" ]; then
      RECOVERY_DEFERRED_TO="$newer"
      echo "[engine-release-transaction] newer release ${newer#* } (run ${newer%% *}) is in flight and owns any off-cycle window; this release waits for the scheduled break"
    fi
    return 0
  fi
  # Lock/source/newest-owner checks can outlive the degradation sample.
  # Revalidate immediately before reserving a pause; recovered play must not
  # be interrupted by the old observation. Unknown health authorizes nothing.
  health="$(curl -sS --max-time 5 http://127.0.0.1:8080/health 2>/dev/null)" || {
    release_engine_lock
    return 0
  }
  if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
    reason="$(recovery_window_reason "$health")"
  elif [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then
    reason="$(owner_window_reason "$health")"
    [ "$reason" = "owner-ordered $ACTIVATION_FLOOR_OWNER_WINDOW" ] || reason=''
  else
    reason="$(recovery_window_reason "$health")"
    if [ "${PHASE1_FLOOR_SELECTED:-0}" = 0 ]; then
      [ -n "$reason" ] || reason="$(owner_window_reason "$health")"
    fi
  fi
  case "${reason%% *}" in
    engine-degraded|owner-ordered|phase1-hourly) ;;
    *)
      release_engine_lock
      return 0
      ;;
  esac
  if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then refuse_foreign_floor_owner; fi
  if [ "${PHASE1_POLICY_OWNED:-0}" = 1 ]; then phase1_custody_admission; fi
  # A closed listener does not resolve a prior unknown native close. On a
  # resumed invocation, require this run's durable completed receipt before
  # either announcing or considering a fresh attachment.
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
    ENGINE_RELEASE_REQUEST_ROOT="$REQUEST_ROOT" \
      python3 "$CONTROL_DIR/main-inspector-retirement.py" --entry-state "$RUN_ID" \
      || die 'prior MAIN Inspector retirement is unresolved; no recovery window requested'
  fi
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && ! legacy_inspector_is_closed; then
    # Only this qualified predecessor has a maintained current-main adoption
    # contract. Do not reuse a reader report or a historical missing intent as
    # action authority. The finite helper rebinds the actual clientless socket,
    # claims this immutable operation durably, and awaits native remote close.
    if [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
      ENGINE_RELEASE_REQUEST_ROOT="$REQUEST_ROOT" ENGINE_LOCK_FILE="$ENGINE_LOCK" \
        CONTAINER="$CONTAINER" python3 "$CONTROL_DIR/main-inspector-retirement.py" "$RUN_ID" "$INVOCATION_ID" \
        || die 'preannouncement MAIN Inspector retirement refused or unknown; no recovery window requested'
      legacy_inspector_is_closed \
        || die 'preannouncement MAIN Inspector absence not verified after retirement'
    else
      release_engine_lock
      RECOVERY_NEXT_EVALUATION=$(( $(date +%s) + RECOVERY_DEFER_SECONDS ))
      echo '[engine-release-transaction] legacy inspector absence is not proved; no recovery window requested and no inspector was touched'
      return 0
    fi
  fi
  FLOOR_RESERVATION_FRESH=0
  if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ] || [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
    [ "$FLOOR_DISPOSITION" != never-entered ] || FLOOR_RESERVATION_FRESH=1
    # The existing reservation/announcement is this fresh request's first
    # runtime-capable action. Persist ownership before any unknown outcome.
    record_floor_runtime_entry announcement-entry
    FLOOR_DISPOSITION=announced
  fi
  reserve_args=(--sha "$SHA" --run-id "$RUN_ID" --repo "$REPO_DIR")
  reserve_args+=(--cause "$(recovery_cause "${reason%% *}")")
  if [ "${reason%% *}" = phase1-hourly ]; then
    reserve_args+=(--scheduled-cycle-start "$PHASE1_CYCLE_START" --control-sha "$CONTROL_SHA")
  fi
  reserve_args+=(--include-eligibility)
  if ! stamp="$(timeout --signal=TERM --kill-after=1s 15s "$RELEASE_SEAL" reserve-recovery-window \
    "${reserve_args[@]}")"; then
    # NOT FATAL (2026-10-02). A refused or slow reservation asks for nothing:
    # no announcement was sent, so this release simply waits for the
    # scheduled break, exactly as a rate-limited one does. Dying here failed
    # three releases on 2026-10-02 whose only fault was a slow seal read.
    release_engine_lock
    RECOVERY_NEXT_EVALUATION=$(( $(date +%s) + RECOVERY_DEFER_SECONDS ))
    echo "[engine-release-transaction] recovery announcement reservation could not be established; no window was announced, waiting for the scheduled break"
    return 0
  fi
  if [[ "$stamp" =~ ^rate-limited:([1-9][0-9]{12})$ ]]; then
    # The seal owns the rolling-hour boundary under its existing lock. Resume
    # this bounded transaction at that boundary, rounded UP to its clock unit;
    # a blind sixty seconds can skip the owner's only permitted minute.
    # The next pass still rechecks owner minute, health, source and ownership.
    RECOVERY_NEXT_EVALUATION=$(( (BASH_REMATCH[1] + 999) / 1000 ))
    if [ "${FLOOR_RESERVATION_FRESH:-0}" = 1 ]; then retire_unannounced_floor_entry; fi
    release_engine_lock
    echo "[engine-release-transaction] off-cycle window wanted ($reason) but the seal's rolling-hour boundary has not elapsed; re-evaluate at $RECOVERY_NEXT_EVALUATION"
    return 0
  fi
  if [ "$stamp" = rate-limited ]; then
    if [ "${FLOOR_RESERVATION_FRESH:-0}" = 1 ]; then retire_unannounced_floor_entry; fi
    release_engine_lock
    RECOVERY_NEXT_EVALUATION=$(( $(date +%s) + RECOVERY_DEFER_SECONDS ))
    echo "[engine-release-transaction] off-cycle window wanted ($reason) but one was already announced in the last hour; waiting for the scheduled break"
    return 0
  fi
  RECOVERY_CHECKED_CAUSE="$cause_key"
  if [ "$stamp" = unavailable ]; then
    if [ "${FLOOR_RESERVATION_FRESH:-0}" = 1 ]; then retire_unannounced_floor_entry; fi
    release_engine_lock
    return 0
  fi
  [[ "$stamp" =~ ^[1-9][0-9]{12}$ ]] || die 'invalid recovery announcement timestamp'
  if [ -n "${ACTIVATION_FLOOR_OWNER_WINDOW:-}" ]; then
    [ "$(floor_reservation_stamp)" = "$stamp" ] || die 'recovery reservation differs from immutable owner window'
  fi
  cause_required="$(printf '%s' "$health" | python3 -c '
import json,sys
print(1 if (json.load(sys.stdin).get("maintenance") or {}).get("recoveryWindowCauseRequired") is True else 0)
')" || return 0
  RECOVERY_REQUESTED=1
  echo "[engine-release-transaction] off-cycle recovery window reason: $reason"
  # The configured key stays inside the running engine container. The API is
  # loopback-only and has the same maintenance/database owner as hourly work.
  # A lost response is UNKNOWN; observe the certificate, never allocate a new
  # timestamp or send another announcement in this invocation.
  outcome="$(timeout --signal=TERM --kill-after=1s 20s docker exec -i "$CONTAINER" \
    node - "$stamp" "$(recovery_cause "${reason%% *}")" "$cause_required" <<'NODE'
const announcedAt=Number(process.argv[2]);
const cause=process.argv[3];
const causeRequired=process.argv[4]==="1";
const key=process.env.INTERNAL_API_KEY;
if (!key) process.exit(1);
fetch('http://127.0.0.1:8080/internal/maintenance-recovery-window', {
  method:'POST', headers:{authorization:`Bearer ${key}`,'content-type':'application/json'},
  body:JSON.stringify(causeRequired ? {announcedAt,cause} : {announcedAt}), signal:AbortSignal.timeout(15000)
}).then(async r=>{
  const d=await r.json();
  if (!r.ok || !['accepted','active','pending','busy','expired','use_hourly','unavailable'].includes(d.status)) process.exit(1);
  console.log(d.status);
}).catch(()=>process.exit(1));
NODE
)" || outcome=unknown
  release_engine_lock
  echo "[engine-release-transaction] fixed recovery announcement $stamp: $outcome; existing certificate and rollback budget remain required"
}

persist_break_deadline() {
  local temporary
  temporary="$REQUEST_ROOT/.$RUN_ID.break-deadline.$$"
  trap 'rm -f -- "${temporary:-}"' RETURN
  umask 077
  printf '%s\n' "$BREAK_END_EPOCH" > "$temporary"
  bounded_break_command 10 python3 - "$temporary" "$REQUEST_ROOT" <<'PY'
import os, sys
for path in sys.argv[1:]:
    flags = os.O_RDONLY | (getattr(os, "O_DIRECTORY", 0) if os.path.isdir(path) else 0)
    fd = os.open(path, flags)
    try: os.fsync(fd)
    finally: os.close(fd)
PY
  bounded_break_command 10 mv -fT -- "$temporary" "$BREAK_DEADLINE_FILE"
  bounded_break_command 10 python3 - "$REQUEST_ROOT" <<'PY'
import os, sys
fd = os.open(sys.argv[1], os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
try: os.fsync(fd)
finally: os.close(fd)
PY
  trap - RETURN
}

clear_break_deadline() {
  local remaining
  remaining=$((BREAK_END_EPOCH - $(date +%s)))
  [ "$remaining" -gt 2 ] || return 1
  [ "$remaining" -le 10 ] || remaining=10
  timeout --signal=TERM --kill-after=1s "${remaining}s" rm -f -- "$BREAK_DEADLINE_FILE" \
    || return 1
  remaining=$((BREAK_END_EPOCH - $(date +%s)))
  [ "$remaining" -gt 2 ] || return 1
  [ "$remaining" -le 10 ] || remaining=10
  timeout --signal=TERM --kill-after=1s "${remaining}s" python3 - "$REQUEST_ROOT" <<'PY'
import os, sys
fd = os.open(sys.argv[1], os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
try: os.fsync(fd)
finally: os.close(fd)
PY
}

break_proof_seconds() {
  local remaining=$((BREAK_END_EPOCH - $(date +%s) - BREAK_ROLLBACK_RESERVE_SECONDS))
  [ "$remaining" -gt 0 ] || return 1
  printf '%s\n' "$remaining"
}

assert_break_proof_time() {
  break_proof_seconds >/dev/null \
    || die 'maintenance break no longer has the reserved proof and rollback budget'
}

bounded_break_command() {
  local requested="$1" proof_remaining overall_remaining allowed
  shift
  proof_remaining="$(break_proof_seconds)" || return 124
  overall_remaining="$(remaining_seconds)" || return 124
  [ "$proof_remaining" -le "$overall_remaining" ] \
    || proof_remaining="$overall_remaining"
  # GNU timeout may spend one additional second between TERM and KILL. Leave
  # another second for the shell to enter the recovery trap before the fixed
  # rollback reserve begins.
  [ "$proof_remaining" -gt 2 ] || return 124
  allowed=$((proof_remaining - 2))
  [ "$requested" -le "$allowed" ] || requested="$allowed"
  legacy_entry_read timeout --signal=TERM --kill-after=1s "${requested}s" "$@"
}

persist_result() {
  local result="$1" instance="$2" image_id container_id started_at recorded result_timeout
  local -a recovery_args=()
  result_timeout=10
  if [ "$result" = already-released ] && [ "${BREAK_END_EPOCH:-0}" -eq 0 ]; then
    # Only the existing duplicate-completion event can retire an orphaned
    # foreign finalization; the seal independently proves both native owners,
    # the actual inherited lock and fresh same-image runtime/database proof.
    recovery_args=(--recover-orphan-finalization-fd 9)
    result_timeout="$(remaining_seconds)" || die 'deadline expired before completion proof'
    [ "$result_timeout" -le 60 ] || result_timeout=60
  fi
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    image_id="$(bounded_break_command 10 "$RELEASE_SEAL" get desired-image-id)"
    container_id="$(bounded_break_command 10 docker container inspect -f '{{.Id}}' "$CONTAINER")"
    started_at="$(bounded_break_command 10 docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")"
  else
    image_id="$(timeout --signal=TERM --kill-after=2s 10s \
      "$RELEASE_SEAL" get desired-image-id)"
    container_id="$(timeout --signal=TERM --kill-after=2s 10s \
      docker container inspect -f '{{.Id}}' "$CONTAINER")"
    started_at="$(timeout --signal=TERM --kill-after=2s 10s \
      docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")"
  fi
  [[ "$container_id" =~ ^[0-9a-f]{64}$ ]] || die 'result container ID is invalid'
  [ -n "$started_at" ] || die 'result container start generation is missing'
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    recorded="$(bounded_break_command 10 "$RELEASE_SEAL" record-result \
      --sha "$SHA" --image-id "$image_id" --result "$result" \
      --instance-id "$instance" --container-id "$container_id" --started-at "$started_at" \
      --run-id "$RUN_ID" --control-sha "$CONTROL_SHA" --invocation-id "$INVOCATION_ID")" \
      || die 'durable per-run release result could not be recorded'
  else
    recorded="$(timeout --signal=TERM --kill-after=2s "${result_timeout}s" \
      "$RELEASE_SEAL" record-result \
      --sha "$SHA" --image-id "$image_id" --result "$result" \
      --instance-id "$instance" --container-id "$container_id" --started-at "$started_at" \
      --run-id "$RUN_ID" --control-sha "$CONTROL_SHA" --invocation-id "$INVOCATION_ID" \
      "${recovery_args[@]}")" \
      || die 'durable per-run release result could not be recorded'
  fi
  case "$recorded" in sealed|already-released) ;; *) die 'durable result returned an invalid outcome' ;; esac
  echo "ENGINE_RELEASE_RESULT=$recorded"
  echo "ENGINE_RELEASE_SHA=$SHA"
  echo "ENGINE_RELEASE_IMAGE_ID=$image_id"
  echo "ENGINE_RELEASE_CONTAINER_ID=$container_id"
  echo "ENGINE_RELEASE_STARTED_AT=$started_at"
}

exact_runtime_instance() {
  local desired desired_image actual actual_image state local_instance public_instance
  desired="$(legacy_entry_read "$RELEASE_SEAL" get desired-sha 2>/dev/null)" || return 1
  [ "$desired" = "$SHA" ] || return 1
  desired_image="$(legacy_entry_read "$RELEASE_SEAL" get desired-image-id 2>/dev/null)" || return 1
  actual="$(legacy_entry_read docker container inspect -f '{{index .Config.Labels "sp.release.sha"}}' "$CONTAINER" 2>/dev/null)" || return 1
  state="$(legacy_entry_read docker container inspect -f '{{.State.Status}}' "$CONTAINER" 2>/dev/null)" || return 1
  actual_image="$(legacy_entry_read docker container inspect -f '{{.Image}}' "$CONTAINER" 2>/dev/null)" || return 1
  [ "$actual" = "$SHA" ] && [ "$state" = running ] && [ "$actual_image" = "$desired_image" ] \
    || return 1
  local_instance="$(health_instance 'http://127.0.0.1:8080/health')" || return 1
  public_instance="$(health_instance "$PUBLIC_URL/health?nocache=$(date +%s%N)")" || return 1
  [ "$local_instance" = "$public_instance" ] || return 1
  printf '%s\n' "$local_instance"
}

# THE CENSUS IS ENTERED ONLY WHEN IT FITS (2026-10-31, LEGACY_CENSUS_* above).
# Reads the serving eed06fe5's own /health heap. 0 fits, 1 does not fit, 3
# could not tell. Only 0 permits the census; "could not tell" is never a fit
# (CLAUDE.md 10.86 rule 1), and a heap that is absent is never a zero.
legacy_census_fits() {
  local response http_code body
  response="$(legacy_entry_read curl -sS --max-time 5 --write-out $'\n%{http_code}' \
    http://127.0.0.1:8080/health 2>/dev/null)" || return 3
  http_code="${response##*$'\n'}"
  body="${response%$'\n'*}"
  case "$http_code" in 200|503) ;; *) return 3 ;; esac
  printf '%s' "$body" | EXPECTED_SHA="$CHECKPOINT_EED_SHA" MS_PER_MB="$LEGACY_CENSUS_MS_PER_HEAP_MB" \
    ALLOWANCE_MS="$LEGACY_CENSUS_ALLOWANCE_MS" legacy_entry_read python3 -c '
import json, math, os, sys
try: d = json.load(sys.stdin)
except Exception: raise SystemExit(3)
if not isinstance(d, dict) or d.get("releaseSha") != os.environ["EXPECTED_SHA"]: raise SystemExit(3)
memory = d.get("memory")
heap = memory.get("heapUsedMb") if isinstance(memory, dict) else None
if isinstance(heap, bool) or not isinstance(heap, (int, float)) or not math.isfinite(heap) or heap <= 0:
    raise SystemExit(3)
# heapUsedMb is rounded; one more MB keeps the estimate on the high side.
need = math.ceil((heap + 1) * int(os.environ["MS_PER_MB"]))
allowance = int(os.environ["ALLOWANCE_MS"])
fits = need <= allowance
sys.stderr.write("[engine-release-transaction] legacy census estimate heapUsedMb=%s censusEstimateMs=%d allowanceMs=%d fits=%s\n" % (heap, need, allowance, fits))
raise SystemExit(0 if fits else 1)
'
}

# The database half of a drained hand boundary for eed06fe5. Exit 0 only when
# the helper read every witness and every one is quiet; 1 is "a hand is
# reserved, retained or moving"; anything else is UNKNOWN and refuses.
#
# IT NEVER RE-ARMS THE CALLER'S ERREXIT (2026-11-01). This function used to end
# its read with a bare `set -e`. The pre-notice gate calls it under `set +e`
# so that a "not drained" answer (1) is recorded, not fatal - but the bare
# `set -e` switched errexit back on inside the function, so its own `return 1`
# then terminated the whole transaction at the call site. Receiver 41272121963
# (ca8250444e, 04:32Z) logged "no cutover this pass" and died 0 s later with
# status 1, 22 s after intake: every mid-play intake whose census cannot fit
# was killed before it could wait for a break. The caller's state is restored
# exactly as it was found.
drained_predecessor_witness() {
  local rc restore_errexit=0
  case "$-" in *e*) restore_errexit=1 ;; esac
  set +e
  legacy_entry_read "$INFLIGHT_HANDS" --env-file "$ENV_FILE" --drained-predecessor --timeout-seconds 5 >&2
  rc=$?
  [ "$restore_errexit" = 0 ] || set -e
  case "$rc" in
    0) echo "[engine-release-transaction] the database confirms a drained hand boundary: no tournament hand or incomplete snapshot moving, no recently formed Lightning hand unsettled" >&2 ;;
    1) echo "[engine-release-transaction] the database says the predecessor is not at a drained hand boundary; no cutover this pass" >&2 ;;
    126|127) echo "[engine-release-transaction] UNKNOWN: $INFLIGHT_HANDS is missing or not executable (status $rc); the drained-boundary witness was NEVER ASKED" >&2; rc=3 ;;
    3) echo "[engine-release-transaction] UNKNOWN: the drained-boundary witness could not be read; no cutover" >&2 ;;
    *) echo "[engine-release-transaction] UNKNOWN: the drained-boundary witness exited $rc; no cutover" >&2; rc=3 ;;
  esac
  return "$rc"
}

prove_rollback_readiness() {
  local rollback_sha rollback_image rollback_legacy rollback_cid rollback_started_at
  local actual_image actual_release state autoheal_label role_label restart_policy autoheal_state
  local local_instance public_instance final_cid final_started_at final_local final_public image_source

  [ -s "$ENV_FILE" ] || die 'rollback readiness refused an absent or empty engine environment'
  if grep -Eq '^[[:space:]]*(GIT_COMMIT_SHA|ENGINE_VERSION)[[:space:]]*=' "$ENV_FILE"; then
    die 'rollback readiness refused a reserved image-version override in the engine environment'
  fi
  bounded_break_command 8 docker info >/dev/null \
    || die 'rollback readiness could not reach Docker before mutation'
  rollback_sha="$(bounded_break_command 8 "$RELEASE_SEAL" get desired-sha)" \
    || die 'rollback readiness could not read the sealed desired SHA'
  rollback_image="$(bounded_break_command 8 "$RELEASE_SEAL" get desired-image-id)" \
    || die 'rollback readiness could not read the sealed desired image'
  rollback_legacy="$(bounded_break_command 8 "$RELEASE_SEAL" get desired-legacy-unlabelled)" \
    || die 'rollback readiness could not read the sealed legacy state'
  [[ "$rollback_sha" =~ ^[0-9a-f]{40}$ ]] \
    && [[ "$rollback_image" =~ ^sha256:[0-9a-f]{64}$ ]] \
    || die 'rollback readiness found an invalid sealed desired identity'
  case "$rollback_legacy" in true|false) ;; *) die 'rollback readiness found invalid legacy state' ;; esac
  bounded_break_command 8 docker image inspect "$rollback_image" >/dev/null \
    || die 'rollback readiness found the sealed desired image absent'
  image_source="$(bounded_break_command 8 docker image inspect \
    --format '{{json .Config.Env}}' "$rollback_image" | python3 -c '
import json,re,sys
entries=json.load(sys.stdin)
if not isinstance(entries,list): raise SystemExit(1)
values=[v.split("=",1)[1] for v in entries if isinstance(v,str) and v.startswith("GIT_COMMIT_SHA=")]
if len(values)!=1 or not re.fullmatch(r"[0-9a-f]{40}",values[0]): raise SystemExit(1)
print(values[0])
')" || die 'rollback readiness found no unique full image source'
  [ "$image_source" = "$rollback_sha" ] \
    || die 'rollback readiness found image source different from the durable seal'

  rollback_cid="$(bounded_break_command 8 docker container inspect -f '{{.Id}}' "$CONTAINER")" \
    || die 'rollback readiness could not identify the serving desired container'
  rollback_started_at="$(bounded_break_command 8 docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")" \
    || die 'rollback readiness could not identify the serving desired generation'
  actual_image="$(bounded_break_command 8 docker container inspect -f '{{.Image}}' "$CONTAINER")"
  actual_release="$(bounded_break_command 8 docker container inspect -f '{{index .Config.Labels "sp.release.sha"}}' "$CONTAINER")"
  state="$(bounded_break_command 8 docker container inspect -f '{{.State.Status}}' "$CONTAINER")"
  autoheal_label="$(bounded_break_command 8 docker container inspect -f '{{index .Config.Labels "autoheal"}}' "$CONTAINER")"
  role_label="$(bounded_break_command 8 docker container inspect -f '{{index .Config.Labels "sp.role"}}' "$CONTAINER")"
  restart_policy="$(bounded_break_command 8 docker container inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$CONTAINER")"
  autoheal_state="$(bounded_break_command 8 docker container inspect -f '{{.State.Status}}' sp-autoheal)"
  [[ "$rollback_cid" =~ ^[0-9a-f]{64}$ ]] && [ -n "$rollback_started_at" ] \
    && [ "$actual_image" = "$rollback_image" ] && [ "$state" = running ] \
    && { [ "$actual_release" = "$rollback_sha" ] \
      || { [ "$rollback_legacy" = true ] && [ -z "$actual_release" ]; }; } \
    && [ "$autoheal_label" = true ] && [ "$role_label" = engine ] \
    && [ "$restart_policy" = always ] && [ "$autoheal_state" = running ] \
    || die 'rollback readiness found the sealed desired run specification inexact or not live'

  local_instance="$(source_instance_for_sha 'http://127.0.0.1:8080/health' "$rollback_sha")" \
    || die 'rollback readiness found no exact desired local identity and liveness'
  public_instance="$(source_instance_for_sha "$PUBLIC_URL/health?nocache=$(date +%s%N)" "$rollback_sha")" \
    || die 'rollback readiness found no exact desired public identity and liveness'
  [ "$local_instance" = "$public_instance" ] \
    || die 'rollback readiness found different local and public desired processes'
  bounded_break_command 18 "$DATABASE_PROOF" --env-file "$ENV_FILE" \
    --sha "$rollback_sha" --instance-id "$local_instance" --timeout-seconds 15 \
    --poll-seconds 3 --max-heartbeat-age-seconds 15 \
    || die 'rollback readiness found no fresh exact desired database leader'

  final_cid="$(bounded_break_command 8 docker container inspect -f '{{.Id}}' "$CONTAINER")"
  final_started_at="$(bounded_break_command 8 docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")"
  final_local="$(source_instance_for_sha 'http://127.0.0.1:8080/health' "$rollback_sha")" \
    || die 'rollback readiness lost exact desired local identity and liveness'
  final_public="$(source_instance_for_sha "$PUBLIC_URL/health?nocache=$(date +%s%N)" "$rollback_sha")" \
    || die 'rollback readiness lost exact desired public identity and liveness'
  [ "$final_cid" = "$rollback_cid" ] && [ "$final_started_at" = "$rollback_started_at" ] \
    && [ "$final_local" = "$local_instance" ] && [ "$final_public" = "$local_instance" ] \
    || die 'rollback readiness changed generation during its proof'
  echo "[engine-release-transaction] exact desired rollback source $rollback_sha is live locally and publicly with a fresh database leader as $local_instance"
}

emit_already_released() {
  local instance="$1" remaining proof_timeout
  remaining="$(remaining_seconds)" || die 'deadline expired before duplicate database proof'
  proof_timeout="$remaining"
  [ "$proof_timeout" -le 45 ] || proof_timeout=45
  [ "$proof_timeout" -ge 17 ] || die 'insufficient time for duplicate database proof'
  proof_timeout=$((proof_timeout - 2))
  timeout --signal=TERM --kill-after=1s "${proof_timeout}s" \
    "$DATABASE_PROOF" --env-file "$ENV_FILE" --sha "$SHA" --instance-id "$instance" \
    --timeout-seconds "$proof_timeout" --poll-seconds 5 \
    || die 'exact runtime is not the freshly elected database leader'
  persist_result already-released "$instance"
  exit 0
}

drill_git() {
  local deadline="$1" remaining
  shift
  remaining=$((deadline - $(date +%s)))
  [ "$remaining" -gt 2 ] || return 124
  [ "$remaining" -le 10 ] || remaining=10
  timeout --signal=TERM --kill-after=1s "${remaining}s" env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" "$@"
}

# The only admission an OLDER target ever gets. Strictly older than the sealed
# high-water, at or above both compatibility floors, and already sealed on this
# very host once - so it has served on this database before. The seal repeats
# the ancestry and not-desired rules at prepare (cmd_prepare, mode rollback).
drill_rollback_admission() {
  local high_water="$1" source_deadline="$2" floor
  [[ "$high_water" =~ ^[0-9a-f]{40}$ ]] \
    || die "rollback drill target $SHA cannot prove the sealed high-water release"
  [ "$SHA" != "$high_water" ] \
    || die 'rollback drill target is the sealed high-water release itself'
  drill_git "$source_deadline" merge-base --is-ancestor "$SHA" "$high_water" \
    || die "rollback drill target $SHA is not older than the sealed high-water release $high_water"
  for floor in "$DRILL_ENGINE_FLOOR_SHA" "$DRILL_TOURNAMENT_FLOOR_SHA"; do
    drill_git "$source_deadline" merge-base --is-ancestor "$floor" "$SHA" \
      || die "rollback drill target $SHA is below the compatibility floor $floor"
  done
  timeout --signal=TERM --kill-after=1s 10s \
    "$RELEASE_SEAL" attest-committed-sha --sha "$SHA" >/dev/null \
    || die "rollback drill target $SHA was never sealed on this host"
  SUPERSEDED_BY=''
}

# Each drill's relation to the sealed desired and high-water releases. Checked
# before the build and again under the engine lock at the break, because an
# ordinary release may have moved either one while the drill waited.
drill_preconditions() {
  local desired high_water
  [ -n "${DRILL_MODE:-}" ] || return 0
  desired="$(timeout --signal=TERM --kill-after=1s 10s "$RELEASE_SEAL" get desired-sha)" \
    || die 'engine drill could not read the sealed desired release'
  high_water="$(timeout --signal=TERM --kill-after=1s 10s "$RELEASE_SEAL" get high-water-sha)" \
    || die 'engine drill could not read the sealed high-water release'
  case "$DRILL_MODE" in
    rollback)
      [ "$SHA" != "$desired" ] \
        || die 'rollback drill target already is the sealed desired release'
      ;;
    rollforward)
      [ "$SHA" = "$high_water" ] \
        || die "rollforward drill target $SHA must be the sealed high-water release $high_water"
      [ "$desired" != "$high_water" ] \
        || die 'rollforward drill found no rolled-back release to roll forward from'
      ;;
  esac
  DRILL_PREVIOUS_DESIRED="$desired"
}

# Evidence, not authority: the seal result above is the receipt the release
# lane trusts. A drill record that cannot be written is said loudly and never
# turns a sealed, proved release into a failure (that would send recovery after
# a healthy engine).
record_drill_receipt() {
  local result="$1" instance="$2"
  [ -n "${DRILL_MODE:-}" ] || return 0
  if ! DRILL_RESULT_DIR="${ENGINE_DRILL_RESULT_DIR:-/var/lib/club-arena/engine-rollback-drill-results}" \
    DRILL_MODE="$DRILL_MODE" DRILL_REASON="$DRILL_REASON" \
    DRILL_RESULT="$result" DRILL_INSTANCE="$instance" DRILL_RUN_ID="$RUN_ID" DRILL_SHA="$SHA" \
    DRILL_CONTROL_SHA="$CONTROL_SHA" DRILL_ACTOR="$ACTOR" DRILL_RUN_URL="$RUN_URL" \
    DRILL_INVOCATION_ID="$INVOCATION_ID" DRILL_BREAK_END_EPOCH="${BREAK_END_EPOCH:-0}" \
    DRILL_PREVIOUS_DESIRED="${DRILL_PREVIOUS_DESIRED:-}" \
    timeout --signal=TERM --kill-after=1s 10s python3 - <<'PY'
import json, os, time
env = os.environ
directory = env["DRILL_RESULT_DIR"]
os.makedirs(directory, mode=0o700, exist_ok=True)
record = {
    "schema": "engine-drill-result-v1",
    "runId": env["DRILL_RUN_ID"],
    "mode": env["DRILL_MODE"],
    "reason": env["DRILL_REASON"],
    "result": env["DRILL_RESULT"],
    "sha": env["DRILL_SHA"],
    "previousDesiredSha": env["DRILL_PREVIOUS_DESIRED"],
    "controlSha": env["DRILL_CONTROL_SHA"],
    "actor": env["DRILL_ACTOR"],
    "runUrl": env["DRILL_RUN_URL"],
    "invocationId": env["DRILL_INVOCATION_ID"],
    "instanceId": env["DRILL_INSTANCE"],
    "breakEndEpoch": int(env["DRILL_BREAK_END_EPOCH"]),
    "completedAt": int(time.time()),
}
path = os.path.join(directory, env["DRILL_RUN_ID"] + ".json")
temporary = path + ".tmp." + str(os.getpid())
with open(temporary, "w", encoding="utf-8") as handle:
    json.dump(record, handle, sort_keys=True)
    handle.write("\n")
    handle.flush()
    os.fsync(handle.fileno())
os.chmod(temporary, 0o600)
os.replace(temporary, path)
fd = os.open(directory, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
try: os.fsync(fd)
finally: os.close(fd)
PY
  then
    echo "[engine-release-transaction] WARN: the engine drill receipt for run $RUN_ID could not be written; the seal result above still stands" >&2
    return 0
  fi
  echo "ENGINE_DRILL_MODE=$DRILL_MODE"
  echo "ENGINE_DRILL_RESULT=$result"
  echo "ENGINE_DRILL_INSTANCE=$instance"
}

create_image_lease() {
  local temporary existing
  install -d -m 0700 "$LEASE_ROOT"
  python3 - "$LEASE_ROOT" "$(dirname "$LEASE_ROOT")" <<'PY'
import os, sys
for path in sys.argv[1:]:
    fd = os.open(path, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
    try: os.fsync(fd)
    finally: os.close(fd)
PY
  temporary="$LEASE_ROOT/.$RUN_ID.lease.$$"
  trap 'rm -f -- "${temporary:-}"' RETURN
  umask 077
  printf '%s\n' "$SHA" > "$temporary"
  python3 - "$temporary" "$LEASE_ROOT" <<'PY'
import os, sys
for path in sys.argv[1:]:
    fd = os.open(path, os.O_RDONLY | (getattr(os, "O_DIRECTORY", 0) if os.path.isdir(path) else 0))
    try: os.fsync(fd)
    finally: os.close(fd)
PY
  if ! ln -- "$temporary" "$LEASE_FILE" 2>/dev/null; then
    mapfile -t existing < "$LEASE_FILE" || die 'existing image lease is unreadable'
    [ "${#existing[@]}" = 1 ] && [ "${existing[0]}" = "$SHA" ] \
      || die 'this run key already leases a different image SHA'
  fi
  rm -f -- "$temporary"
  python3 - "$LEASE_ROOT" <<'PY'
import os, sys
fd = os.open(sys.argv[1], os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
try: os.fsync(fd)
finally: os.close(fd)
PY
  trap - RETURN
}

validate_candidate_image() {
  local identity
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    identity="$(bounded_break_command 10 docker image inspect --format '{{json .}}' "$IMAGE_REF")" \
      || die 'candidate image tag is absent'
  else
    local remaining
    remaining="$(remaining_seconds)" || die 'candidate image verification deadline expired'
    [ "$remaining" -le 10 ] || remaining=10
    identity="$(timeout --signal=KILL "${remaining}s" docker image inspect --format '{{json .}}' "$IMAGE_REF")" \
      || die 'candidate image tag is absent before maintenance'
  fi
  mapfile -t IMAGE_FIELDS < <(printf '%s' "$identity" \
    | EXPECTED_SHA="$SHA" EXPECTED_TREE="$EXPECTED_SERVER_TREE" python3 -c '
import json, os, re, sys
d=json.load(sys.stdin)
labels=(d.get("Config") or {}).get("Labels") or {}
image_id=str(d.get("Id") or "")
revision=str(labels.get("org.opencontainers.image.revision") or "")
tree=str(labels.get("com.smarterpoker.engine.source-tree") or "")
contract=str(labels.get("com.smarterpoker.engine.build-contract") or "")
ok=(re.fullmatch(r"sha256:[0-9a-f]{64}",image_id) and revision==os.environ["EXPECTED_SHA"] and tree==os.environ["EXPECTED_TREE"] and contract=="clean-server-archive-v1")
if not ok: raise SystemExit(1)
print(image_id)
print(revision)
print(tree)
print(contract)
' 2>/dev/null) || die 'candidate image identity or provenance is invalid'
  [ "${#IMAGE_FIELDS[@]}" = 4 ] || die 'candidate image identity has an invalid field count'
  TARGET_IMAGE_ID="${IMAGE_FIELDS[0]}"
}

# Use the same isolated preparation before intake and again before maintenance.
# Resolve the tag once; the helper accepts and runs only an immutable image ID.
prewarm_candidate_image() {
  local image_id remaining inspect_timeout
  remaining="$(remaining_seconds)" || die 'deadline expired before image preparation identity'
  [ "$remaining" -gt 12 ] || die 'insufficient image preparation identity budget'
  inspect_timeout=$((remaining - 2))
  [ "$inspect_timeout" -le 10 ] || inspect_timeout=10
  image_id="$(timeout --signal=TERM --kill-after=1s "${inspect_timeout}s" \
    docker image inspect --format '{{.Id}}' "$IMAGE_REF")" \
    || die 'candidate image preparation identity is unavailable'
  "$CONTROL_DIR/prewarm-engine-image.sh" "$image_id" "$RUN_ID" "$MUTATION_DEADLINE_EPOCH" \
    || die 'candidate filesystem warm-up did not finish before maintenance'
  validate_candidate_image
  [ "$TARGET_IMAGE_ID" = "$image_id" ] || die 'candidate changed during filesystem warm-up'
  local predecessor
  predecessor="$(timeout --signal=KILL 5s "$RELEASE_SEAL" get desired-sha)" \
    || die 'checkpoint preparation predecessor is unreadable'
  case "$predecessor" in
    "$LEGACY_CHECKPOINT_SHA"|"$CHECKPOINT_758_SHA"|"$CHECKPOINT_A0_SHA"|"$CHECKPOINT_8825_SHA"|"$CHECKPOINT_EED_SHA")
      "$LEGACY_CHECKPOINT" --prepare-native-census "$RUN_ID" "$SHA" "$TARGET_IMAGE_ID" "$EXPECTED_SERVER_TREE" "$MUTATION_DEADLINE_EPOCH" \
        || die 'immutable native checkpoint artifact preparation failed before maintenance' ;;
  esac
}

read_pending_owner() {
  local description remaining
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    description="$(bounded_break_command 10 "$RELEASE_SEAL" pending-owner)" \
      || die 'release seal pending owner exceeded the shared break deadline'
  else
    remaining="$(remaining_seconds)" || die 'deadline expired before pending-owner read'
    [ "$remaining" -le 10 ] || remaining=10
    description="$(timeout --signal=TERM --kill-after=1s "${remaining}s" \
      "$RELEASE_SEAL" pending-owner)" \
      || die 'bounded release seal pending owner is unreadable'
  fi
  PENDING_STATE=''
  PENDING_RUN=''
  PENDING_USED=''
  PENDING_EXPIRES=''
  PENDING_EXTRA=''
  read -r PENDING_STATE PENDING_RUN PENDING_USED PENDING_EXPIRES PENDING_EXTRA <<< "$description"
  if [ "$PENDING_STATE" = none ]; then
    [ -z "$PENDING_RUN$PENDING_USED$PENDING_EXPIRES$PENDING_EXTRA" ] \
      || die 'release seal returned a malformed empty pending owner'
    return
  fi
  case "$PENDING_STATE" in active|expired) ;; *) die 'release seal returned an invalid pending lifecycle' ;; esac
  [[ "$PENDING_RUN" =~ ^[1-9][0-9]*(-[1-9][0-9]*)?$ ]] \
    || die 'release seal returned an invalid pending run key'
  case "$PENDING_USED" in true|false) ;; *) die 'release seal returned an invalid pending use state' ;; esac
  [[ "$PENDING_EXPIRES" =~ ^[1-9][0-9]*$ ]] && [ -z "$PENDING_EXTRA" ] \
    || die 'release seal returned an invalid pending expiry'
}

recover_pending_owner() {
  local owner="$1" abort_rc recovery_deadline recovery_remaining non_break_deadline
  MUTATION_STARTED=1
  recovery_deadline="${BREAK_END_EPOCH:-$DEADLINE}"
  if [ "${BREAK_END_EPOCH:-0}" -eq 0 ]; then
    non_break_deadline=$(( $(date +%s) + NON_BREAK_RECOVERY_MAX_SECONDS ))
    [ "$recovery_deadline" -le "$non_break_deadline" ] || recovery_deadline="$non_break_deadline"
  fi
  set +e
  recovery_remaining=$((recovery_deadline - $(date +%s)))
  if [ "$recovery_remaining" -gt 2 ]; then
    [ "$recovery_remaining" -le 10 ] || recovery_remaining=10
    timeout --signal=TERM --kill-after=1s "${recovery_remaining}s" \
      "$RELEASE_SEAL" abort --run-id "$owner"
  else
    false
  fi
  abort_rc=$?
  set -e
  recovery_remaining=$((recovery_deadline - $(date +%s)))
  [ "$recovery_remaining" -gt 2 ] \
    || die "pending release $owner exhausted its exact desired recovery deadline"
  if [ "${BREAK_END_EPOCH:-0}" -gt 0 ]; then
    [ "$recovery_remaining" -le "$BREAK_ROLLBACK_RESERVE_SECONDS" ] \
      || recovery_remaining="$BREAK_ROLLBACK_RESERVE_SECONDS"
  else
    [ "$recovery_remaining" -le "$NON_BREAK_RECOVERY_MAX_SECONDS" ] \
      || recovery_remaining="$NON_BREAK_RECOVERY_MAX_SECONDS"
  fi
  timeout --signal=TERM --kill-after=1s "${recovery_remaining}s" env \
    ENGINE_SUPERVISOR_LOCK_HELD=1 ENGINE_SUPERVISOR_FORCE_DESIRED=1 \
    ENGINE_SUPERVISOR_REQUIRE_EXACT_HEALTH=1 \
    ENGINE_RECOVERY_DEADLINE_EPOCH="$recovery_deadline" \
    ENGINE_CONTROL_DIR="$CONTROL_DIR" CONTAINER="$CONTAINER" ENGINE_URL="$PUBLIC_URL" \
    "$CONTROL_DIR/engine-supervisor.sh" \
    || die "pending release $owner did not restore exact desired local and public health before its recovery deadline"
  [ "$abort_rc" -eq 0 ] \
    || die "pending release $owner was recovered but its abort audit failed"
}

# A floor-aware fresh request has no authority to restore a live predecessor.
# Classify it from exact immutable capability before taking an engine lock.
FLOOR_DISPOSITION="$(python3 "$CONTROL_DIR/engine-release-activation-floor.py" entry-check \
  --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA" \
  --deadline "$MUTATION_DEADLINE_EPOCH" --request-root "$REQUEST_ROOT" --run-id "$RUN_ID")" \
  || die 'immutable activation floor refused runtime admission'
ACTIVATION_FLOOR_END_EPOCH=0
export ACTIVATION_FLOOR_OWNER_WINDOW=
if [ "$FLOOR_DISPOSITION" = never-entered ] || [ "$FLOOR_DISPOSITION" = announced ]; then
  ACTIVATION_FLOOR_JSON="$(python3 "$CONTROL_DIR/engine-release-activation-floor.py" admit \
    --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA" \
    --deadline "$MUTATION_DEADLINE_EPOCH" --request-root "$REQUEST_ROOT" --run-id "$RUN_ID")" || die 'immutable daily activation intent refused'
  # An announced owner whose window has since expired reads 'legacy' from a
  # fresh admit (an expired floor is no floor, 2026-10-30). Its announcement
  # was made under that window, so it ends here by name rather than carrying
  # on as a routine release that never announced.
  if [ "$FLOOR_DISPOSITION" = announced ] && [ "$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("schema",""))')" = legacy-no-activation-floor ]; then
    die 'this run announced inside an owner window that has since expired; its runtime entry is refused'
  fi
  ACTIVATION_FLOOR_END_EPOCH="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("expiresEpoch", 0))')"
  ACTIVATION_FLOOR_OWNER_WINDOW="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("ownerWindowId") or "")')"
  PHASE1_FLOOR_SELECTED="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(1 if json.load(sys.stdin).get("schema")=="engine-release-activation-floor/v3-phase1" else 0)')"
  export PHASE1_FLOOR_SELECTED
fi

record_floor_runtime_entry() {
  legacy_entry_read python3 "$CONTROL_DIR/engine-release-activation-floor.py" "${1:-entry}" \
    --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA" \
    --deadline "$MUTATION_DEADLINE_EPOCH" --request-root "$REQUEST_ROOT" --run-id "$RUN_ID" \
    >/dev/null || die 'immutable activation floor refused actual runtime entry'
}

# Duplicate certification and interrupted recovery retain their original owner.
acquire_engine_lock 'duplicate certification'
# Pure durable ownership read precedes any desired-runtime restoration. New
# source policy/cycle admission still follows canonical committed-run replay.
legacy_entry_read timeout --signal=TERM --kill-after=1s 15s \
  "$RELEASE_SEAL" check-routine-owner --run-id "$RUN_ID" >/dev/null \
  || die 'a prior routine cycle owner remains unresolved'
refuse_foreign_floor_owner
while :; do
  read_pending_owner
  if { [ "$FLOOR_DISPOSITION" = never-entered ] || [ "$FLOOR_DISPOSITION" = announced ]; } && [ "$PENDING_STATE" != none ]; then
    die 'fresh scheduled release cannot take over an existing runtime recovery owner'
  fi
  # A boot-resumed unit owns its exact interrupted receipt. Expired receipts
  # and this run's interrupted receipt are recovered before Git/network work.
  if [ "$PENDING_STATE" = expired ] \
    || { [ "$PENDING_STATE" = active ] && [ "$PENDING_RUN" = "$RUN_ID" ]; }; then
    recover_pending_owner "$PENDING_RUN"
    continue
  fi
  [ "$PENDING_STATE" = active ] || break

  # Never leave a terminal foreign candidate with restart disabled while this
  # run builds or waits for a table break. A genuinely live owner gets a
  # bounded chance to finish; a missing/terminal owner is repaired now.
  FOREIGN_STATE="$(systemctl show "club-arena-engine-release-v1@$PENDING_RUN.service" \
    -p ActiveState --value 2>/dev/null || true)"
  case "$FOREIGN_STATE" in
    active|activating|deactivating)
      release_engine_lock
      bounded_sleep 15
      acquire_engine_lock 'prior release completion'
      ;;
    *)
      recover_pending_owner "$PENDING_RUN"
      ;;
  esac
done
# Commit/abort responses can be interrupted after the fsynced seal mutation
# and before restart policy or desired-container restoration. With no foreign
# pending candidate, repair the sealed desired runtime immediately under the
# mutation lock—never build or wait for another hourly break while service is
# absent merely because a prior response was lost.
if [ "$FLOOR_DISPOSITION" = never-entered ] || [ "$FLOOR_DISPOSITION" = announced ]; then
  # No runtime restoration for a fresh scheduled request. The existing locked
  # proof below verifies sealed/local/public/DB identity immediately before
  # checkpoint or prepare, once, under the actual daily certificate budget.
  :
else
MUTATION_STARTED=1
PREWORK_RECOVERY_REMAINING="$(remaining_seconds)" \
  || die 'deadline expired before sealed desired runtime recovery'
[ "$PREWORK_RECOVERY_REMAINING" -le "$NON_BREAK_RECOVERY_MAX_SECONDS" ] \
  || PREWORK_RECOVERY_REMAINING="$NON_BREAK_RECOVERY_MAX_SECONDS"
PREWORK_RECOVERY_DEADLINE=$(( $(date +%s) + PREWORK_RECOVERY_REMAINING ))
timeout --signal=TERM --kill-after=1s "${PREWORK_RECOVERY_REMAINING}s" env \
  ENGINE_SUPERVISOR_LOCK_HELD=1 ENGINE_SUPERVISOR_FORCE_DESIRED=1 \
  ENGINE_SUPERVISOR_REQUIRE_EXACT_HEALTH=1 \
  ENGINE_RECOVERY_DEADLINE_EPOCH="$PREWORK_RECOVERY_DEADLINE" \
  ENGINE_CONTROL_DIR="$CONTROL_DIR" CONTAINER="$CONTAINER" ENGINE_URL="$PUBLIC_URL" \
  "$CONTROL_DIR/engine-supervisor.sh" \
  || die 'sealed desired runtime could not be restored before release work'
MUTATION_STARTED=0
fi
# Once this exact run crossed the fsynced commit boundary, mutable protected
# main can no longer decide whether its missing result receipt is recoverable.
# Certify the restored exact runtime and elected-leader identity first. This is
# deliberately run-owned: an ordinary duplicate still has to pass freshness.
COMMITTED_IMAGE="$(timeout --signal=TERM --kill-after=2s 10s \
  "$RELEASE_SEAL" get desired-image-id)" \
  || die 'durable desired image is unreadable before committed-run replay'
if "$RELEASE_SEAL" attest-commit \
  --sha "$SHA" --image-id "$COMMITTED_IMAGE" --run-id "$RUN_ID" >/dev/null 2>&1; then
  EXACT_INSTANCE="$(exact_runtime_instance)" \
    || die 'this run committed, but its exact serving runtime could not be certified'
  emit_already_released "$EXACT_INSTANCE"
fi
[ "$(date +%s)" -lt "$MUTATION_DEADLINE_EPOCH" ] \
  || die 'immutable release not-after epoch expired before new release mutation'
source_target_is_current
initialise_phase1_cycle
if EXACT_INSTANCE="$(exact_runtime_instance)" && ! phase1_reset_required; then
  emit_already_released "$EXACT_INSTANCE"
fi
[ -z "${DRILL_MODE:-}" ] || drill_preconditions
release_engine_lock

# The durable unit, not the SSH session, owns image construction. The outer
# timeout bounds both the host build-lock wait and Docker itself. A source
# check after the build repeats protected-main containment and the sealed
# high-water ordering before the candidate waits for a certified table break.
assert_time_remaining
create_image_lease
# The builder owns up to 1,800s of FIFO lock wait and 1,500s of bounded Docker
# work. Its parent must cover both phases; otherwise a current SHA queued
# behind a stale long build can be killed five minutes into its own build and
# leave no surviving release for the next certified break.
BUILD_REMAINING="$(remaining_seconds)" \
  || die 'immutable release not-after epoch expired before image construction'
[ "$BUILD_REMAINING" -gt 16 ] \
  || die 'immutable release not-after epoch has no bounded image-build budget'
BUILD_TIMEOUT=$((BUILD_REMAINING - 16))
[ "$BUILD_TIMEOUT" -le 3450 ] || BUILD_TIMEOUT=3450
timeout --signal=TERM --kill-after=15s "${BUILD_TIMEOUT}s" \
  "$IMAGE_BUILDER" "$REPO_DIR" "$SHA" "$IMAGE_REF" \
  || die 'bounded immutable engine image build failed'
prewarm_candidate_image
source_target_is_current
NEXT_FRESHNESS_CHECK=$(( $(date +%s) + 60 ))
# The receiver/intake already enforced the no-write floor. Rebind it here
# before checkpoint/certificate work; existing interrupted-owner recovery above
# retains its original authority and is never blocked by a later expiry.
ACTIVATION_FLOOR_JSON="$(python3 "$CONTROL_DIR/engine-release-activation-floor.py" admit \
  --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA" \
  --deadline "$MUTATION_DEADLINE_EPOCH" --request-root "$REQUEST_ROOT" --run-id "$RUN_ID")" || die 'immutable daily activation intent refused'
ACTIVATION_FLOOR_END_EPOCH="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("expiresEpoch",0))')"
ACTIVATION_FLOOR_OWNER_WINDOW="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin).get("ownerWindowId") or "")')"
PHASE1_FLOOR_SELECTED="$(printf '%s' "$ACTIVATION_FLOOR_JSON" | python3 -c 'import json,sys; print(1 if json.load(sys.stdin).get("schema")=="engine-release-activation-floor/v3-phase1" else 0)')"
export PHASE1_FLOOR_SELECTED
if [ "$ACTIVATION_FLOOR_END_EPOCH" -gt 0 ] && [ "$CERTIFICATE_DEADLINE" -gt "$ACTIVATION_FLOOR_END_EPOCH" ]; then
  CERTIFICATE_DEADLINE="$ACTIVATION_FLOOR_END_EPOCH"
fi
# This is a compatibility operation for three pinned immutable predecessors, not a
# general checkpoint API. The helper rebinds the seal/image/process under the
# engine lock immediately before its one durable intent and checkpoint.
CHECKPOINT_PREDECESSOR_SHA="$(timeout --signal=TERM --kill-after=1s 10s \
  "$RELEASE_SEAL" get desired-sha)" || die 'sealed checkpoint predecessor is unreadable'
LEGACY_CHECKPOINT_REQUIRED=0
if [ "$CHECKPOINT_PREDECESSOR_SHA" = "$LEGACY_CHECKPOINT_SHA" ] \
  || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_758_SHA" ] \
  || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_A0_SHA" ] \
  || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_8825_SHA" ] \
  || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
  LEGACY_CHECKPOINT_REQUIRED=1
fi
if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && [ "$LEGACY_CHECKPOINT_ATTEMPTED" = 1 ]; then
  # Refused HERE, before a break is entered and before any lock, rather than
  # by the helper crashing on its own O_EXCL write several minutes later.
  #
  # An interrupted transaction resumes correctly for everything else it owns -
  # the sealed desired runtime, a committed-run replay, a pending owner - and
  # those paths all run above this line, so a run that really did finish still
  # reports its receipt. What cannot resume is this: the checkpoint is a
  # one-shot over a live predecessor holding seated stacks, nothing durable
  # records whether an interrupted entry completed it, and "I could not tell"
  # is a refusal, never permission (CLAUDE.md 10.86 rule 1). The intent stands;
  # it is NOT retired here. A later break cannot make it safe either, so this
  # does not wait - it ends, and the next dispatch gets a new run key.
  die 'this run key already opened the one-shot legacy checkpoint and its durable intent is still on disk; whether that entry acted is UNKNOWN, so it may not be entered again - dispatch a new run key'
fi

# REFUSED BEFORE ANY NOTICE (owner, 2026-10-31). eed06fe5's checkpoint needs a
# full-heap native census. When the predecessor's own heap says it cannot fit
# its allowance (or the heap cannot be read), the census is refused HERE,
# before request_recovery_window can announce anything, so no break is spent
# on it and the predecessor's main thread is never blocked by it. The only way
# this release may then replace eed06fe5 is a drained hand boundary, and its
# database witness must be readable now, or this refuses before notice too.
DRAINED_PREDECESSOR_CUTOVER=0
switch_to_drained_predecessor_cutover() {
  [ "${PHASE1_POLICY_OWNED:-0}" = 0 ] || die 'Phase1 requires the full retained-owner checkpoint; an age-only drained boundary is not qualified'
  LEGACY_CHECKPOINT_REQUIRED=0
  DRAINED_PREDECESSOR_CUTOVER=1
  echo "[engine-release-transaction] the full-heap legacy census does not fit (or its heap is unreadable); it is refused and $CHECKPOINT_EED_SHA may be replaced only at a drained hand boundary, never by a checkpoint"
}
# The inverse, used only from the wait loop: the same sealed eed06fe5 restarted
# on its own and its heap fits the census allowance again (see the loop).
return_to_legacy_census_route() {
  DRAINED_PREDECESSOR_CUTOVER=0
  LEGACY_CHECKPOINT_REQUIRED=1
  echo "[engine-release-transaction] the serving $CHECKPOINT_EED_SHA heap fits the legacy census allowance again; the existing checkpoint route is offered again and the drained-boundary route is set aside"
}
if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
  if ! legacy_census_fits; then
    switch_to_drained_predecessor_cutover
    # A list, not `set +e`: "not drained" (1) must never end the transaction
    # here, whatever the function does with errexit (see its header).
    DRAINED_WITNESS_RC=0
    drained_predecessor_witness || DRAINED_WITNESS_RC=$?
    [ "$DRAINED_WITNESS_RC" = 0 ] || [ "$DRAINED_WITNESS_RC" = 1 ] \
      || die 'the legacy census cannot fit and the drained-boundary database witness cannot be read; refusing before any notice so no break is spent'
  fi
fi

# Commit messages are descriptive source data, never authority to stop games.
# In particular, an urgent trailer in this target or any ancestor cannot turn
# routine deployment into off-cycle maintenance. Only current measured engine
# degradation in recovery_window_reason may request that separate emergency.
RECOVERY_WAIT_STARTED_EPOCH="$(date +%s)"
DAILY_TRANSITION=0

# Owner-authorized initial installation, 2026-10-20: one final existing :55
# window, only while the serving engine lacks the new daily schedule. This
# marker cannot request recovery, and a daily engine closes it permanently.
if [ -z "${DRILL_MODE:-}" ] \
  && TRANSITION_HIGH_WATER="$(timeout --signal=TERM --kill-after=1s 10s \
    "$RELEASE_SEAL" get high-water-sha 2>/dev/null)" \
  && [[ "$TRANSITION_HIGH_WATER" =~ ^[0-9a-f]{40}$ ]] \
  && TRANSITION_MESSAGES="$(timeout --signal=TERM --kill-after=1s 10s env GIT_NO_REPLACE_OBJECTS=1 \
    git -C "$REPO_DIR" log --format=%B "$TRANSITION_HIGH_WATER..$SHA" 2>/dev/null)" \
  && grep -Fqx 'Engine-Release: daily-maintenance-transition' <<<"$TRANSITION_MESSAGES"; then
  DAILY_TRANSITION=1
fi

# Built, fresh and about to wait at the certificate: say so for older targets.
# Best effort by design - a marker that cannot be written only means an older
# release keeps racing this one, which is the behaviour before 2026-09-27.
if [ -n "${DRILL_MODE:-}" ]; then
  echo "[engine-release-transaction] engine drill $DRILL_MODE waits at the certificate without asking any release to stand aside"
elif printf '%s\n' "$SHA" > "$AWAITING_CERTIFICATE_FILE.$$" 2>/dev/null \
  && mv -f -- "$AWAITING_CERTIFICATE_FILE.$$" "$AWAITING_CERTIFICATE_FILE" 2>/dev/null; then
  :
else
  rm -f -- "$AWAITING_CERTIFICATE_FILE.$$" 2>/dev/null || true
  echo "[engine-release-transaction] WARN: could not record that $SHA is waiting at the certificate; older releases will not stand aside for it" >&2
fi
while :; do
  if [ "${PHASE1_CYCLE_START:-0}" -gt 0 ]; then
    cycle_limit="${PHASE1_WINDOW_END:-0}"
    [ "$cycle_limit" -gt 0 ] || cycle_limit=$(((PHASE1_CYCLE_START+360)*1000))
    [ "$(date +%s%3N)" -lt "$cycle_limit" ] || die 'original routine cycle expired; no later hour is authorized'
  fi
  [ "$(date +%s)" -lt "$CERTIFICATE_DEADLINE" ] \
    || die 'the engine did not present a restart certificate with enough proof time remaining'
  if [ "$(date +%s)" -ge "$NEXT_FRESHNESS_CHECK" ]; then
    # Recheck containment and sealed high-water while waiting. A newer sealed
    # release revokes an older target; a newer unshipped merge alone does not.
    source_target_is_current
    NEXT_FRESHNESS_CHECK=$(( $(date +%s) + 60 ))
  fi
  # The heap is re-read on every pass, in BOTH directions (2026-11-01).
  #
  # This used to say "the heap only grows while this run waits" and switched
  # one way only: a run that met a large heap once stayed on the drained route
  # for the rest of its life. That premise is false for eed06fe5. It restarts
  # itself on the SAME sealed image every 90-120 minutes (02:19, 03:50, 05:19,
  # 08:15, 09:42, 12:39 UTC on 2026-11-01), and a fresh process measured
  # 350 MB at 97 s and 1906-2200 MB at 20-35 min, inside the census allowance.
  # Run 41283363258 was admitted at 07:19 with a large heap and was still on the
  # drained route at the 10:00 daily break, 18 minutes after the 09:42 restart,
  # where the census would have fitted; five stopped-tournament tables held
  # cards_in_air through that break and the strict certificate never opened.
  #
  # So a run that has not opened the one-shot checkpoint goes back to the
  # existing census route when the same sealed eed06fe5 measures inside its
  # allowance again. Nothing is widened: legacy_census_fits is the same
  # predicate the intake used, the last read before the one-shot intent still
  # refuses a census that stopped fitting, and the certificate after the
  # checkpoint is unchanged. A run that opened the checkpoint never comes back
  # here (LEGACY_CHECKPOINT_ATTEMPTED dies above and below).
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ] \
    && ! legacy_census_fits; then
    switch_to_drained_predecessor_cutover
  elif [ "${DRAINED_PREDECESSOR_CUTOVER:-0}" = 1 ] && [ "$LEGACY_CHECKPOINT_ATTEMPTED" = 0 ] \
    && [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ] && legacy_census_fits; then
    return_to_legacy_census_route
  fi
  # A drained boundary needs Lightning to stop forming hands exactly as the
  # checkpoint did; the hold is the same one, placed by the same predicate.
  if [ "${DRAINED_PREDECESSOR_CUTOVER:-0}" = 1 ]; then hold_lightning_when_counting_down; fi
  # The legacy ladder is derived from the strict figure and keeps it. The
  # ordinary one is admitted by the first certificate the engine can actually
  # present, which is never at t=0: see BREAK_CERTIFICATE_LAG_SECONDS.
  # A hold outlives neither a passed break nor the legacy path that placed it.
  release_lightning_hold_if_break_over
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ]; then
    hold_lightning_when_counting_down
    ENTRY_STARTED_MS="$(date +%s%3N)"
    LEGACY_ENTRY_DEADLINE_MS=$((ENTRY_STARTED_MS + LEGACY_CHECKPOINT_BUDGET_SECONDS * 1000))
    ADMISSION_MIN_BREAK_MS="$MIN_BREAK_REMAINING_MS"
  else
    ADMISSION_MIN_BREAK_MS="$BREAK_ADMISSION_MIN_BREAK_MS"
  fi
  set +e
  BREAK_REMAINING_MS="$(maintenance_certificate "$ADMISSION_MIN_BREAK_MS")"
  CERTIFICATE_RC=$?
  set -e
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ]; then
    # Counting down follows the final announcement. Run even when the old
    # certificate says ready: that predecessor can retain a stale saved bit.
    if ! LEGACY_COUNTDOWN_END="$(legacy_checkpoint_countdown "$BREAK_ENTRY_BUDGET_MS")"; then
      LEGACY_ENTRY_DEADLINE_MS=0
      # These exact successors already implement the original bounded recovery
      # event. Retain that opportunity; the helper still needs its real durable
      # countdown, and an unknown request can never create another announcement.
      if [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_758_SHA" ] \
        || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_A0_SHA" ] \
        || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_8825_SHA" ] \
  || [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
        if [ "$CERTIFICATE_RC" -eq 2 ]; then RECOVERY_ADMISSION_MISSED=1; fi
        request_recovery_window
      fi
      bounded_sleep 5
      continue
    fi
    LEGACY_ENTRY_BREAK_END_EPOCH="$LEGACY_COUNTDOWN_END"
    legacy_entry_trace admitted verified
  elif [ "$CERTIFICATE_RC" -eq 2 ]; then
    note_missed_admission "${BREAK_REMAINING_MS:-0}"
    # A predecessor or image build can consume the beginning of this break.
    # No prepare or break deadline exists yet. Keep the original request's
    # absolute deadline and source-freshness checks while waiting for a later
    # complete certificate; never reduce the candidate-and-recovery reserve.
    echo "[engine-release-transaction] the durable table break has ${BREAK_REMAINING_MS:-0}ms remaining, below the ${ADMISSION_MIN_BREAK_MS}ms candidate-and-recovery budget; refusing before mutation and waiting for a later certificate"
    bounded_sleep 15
    continue
  fi
  if [ "$LEGACY_CHECKPOINT_REQUIRED" != 1 ] && [ "$CERTIFICATE_RC" -ne 0 ]; then
    request_recovery_window
    bounded_sleep 5
    continue
  fi

  if [ "$LEGACY_CHECKPOINT_REQUIRED" != 1 ] && NEWER_WAITING="$(newer_release_awaiting_certificate)"; then
    if [ "$BREAK_DEFERRED_TO" != "$NEWER_WAITING" ]; then
      BREAK_DEFERRED_TO="$NEWER_WAITING"
      echo "[engine-release-transaction] newer release ${NEWER_WAITING#* } (run ${NEWER_WAITING%% *}) contains $SHA and is waiting at this certificate; standing aside so the break ships the newest code"
    fi
    bounded_sleep 5
    continue
  fi
  BREAK_DEFERRED_TO=''
  acquire_engine_lock 'maintenance cutover'
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ]; then legacy_entry_trace locked verified; fi
  source_target_is_current
  if EXACT_INSTANCE="$(exact_runtime_instance)" && ! phase1_reset_required; then
    LEGACY_ENTRY_DEADLINE_MS=0
    emit_already_released "$EXACT_INSTANCE"
  fi
  [ -z "${DRILL_MODE:-}" ] || drill_preconditions
  if [ "${DRAINED_PREDECESSOR_CUTOVER:-0}" = 1 ]; then
    CHECKPOINT_PREDECESSOR_SHA="$(timeout --signal=TERM --kill-after=1s 10s \
      "$RELEASE_SEAL" get desired-sha)" || die 'locked drained-boundary predecessor is unreadable'
    case "$CHECKPOINT_PREDECESSOR_SHA" in
      "$CHECKPOINT_EED_SHA")
        # Under the lock and before the locked certificate, which stays the
        # last read before the break deadline is fixed.
        if ! drained_predecessor_witness; then
          release_engine_lock
          bounded_sleep 5
          continue
        fi
        ;;
      "$LEGACY_CHECKPOINT_SHA"|"$CHECKPOINT_758_SHA"|"$CHECKPOINT_A0_SHA"|"$CHECKPOINT_8825_SHA")
        die 'the sealed predecessor changed to a different legacy profile under the lock; refusing'
        ;;
      *)
        # Another release advanced desired while this run waited; the ordinary
        # rules own its successor, exactly as for the legacy path below.
        DRAINED_PREDECESSOR_CUTOVER=0
        ;;
    esac
  fi
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ]; then
    CHECKPOINT_PREDECESSOR_SHA="$(legacy_entry_read timeout --signal=TERM --kill-after=1s 10s \
      "$RELEASE_SEAL" get desired-sha)" || die 'locked checkpoint predecessor is unreadable'
    if [ "$CHECKPOINT_PREDECESSOR_SHA" != "$LEGACY_CHECKPOINT_SHA" ] \
      && [ "$CHECKPOINT_PREDECESSOR_SHA" != "$CHECKPOINT_758_SHA" ] \
      && [ "$CHECKPOINT_PREDECESSOR_SHA" != "$CHECKPOINT_A0_SHA" ] \
      && [ "$CHECKPOINT_PREDECESSOR_SHA" != "$CHECKPOINT_8825_SHA" ] \
      && [ "$CHECKPOINT_PREDECESSOR_SHA" != "$CHECKPOINT_EED_SHA" ]; then
      # A different release may have advanced desired while this run waited.
      # Source/high-water admission above still owns whether our target may
      # follow it. Never apply the old-image compatibility path to its successor.
      LEGACY_CHECKPOINT_REQUIRED=0
      LEGACY_ENTRY_DEADLINE_MS=0
    fi
  fi
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ] && [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ]; then
    # Scheduled and adopted countdowns bypass request_recovery_window. They
    # must preserve unknown retirement history too, under the same lock and
    # absolute entry clock, before any fresh Inspector or checkpoint call.
    legacy_entry_read timeout --signal=TERM --kill-after=1s 3s \
      env ENGINE_RELEASE_REQUEST_ROOT="$REQUEST_ROOT" \
      python3 "$CONTROL_DIR/main-inspector-retirement.py" --entry-state "$RUN_ID" \
      || die 'locked MAIN Inspector retirement history is unresolved; refusing checkpoint'
  fi
  if [ "$LEGACY_CHECKPOINT_REQUIRED" = 1 ]; then
    if ! LEGACY_COUNTDOWN_END="$(legacy_checkpoint_countdown "$BREAK_ENTRY_BUDGET_MS" "$LEGACY_ENTRY_BREAK_END_EPOCH" locked)"; then
      legacy_entry_trace refused countdown_refused
      LEGACY_ENTRY_DEADLINE_MS=0
      release_engine_lock
      bounded_sleep 5
      continue
    fi
    [ "$LEGACY_CHECKPOINT_ATTEMPTED" = 0 ] \
      || die 'legacy checkpoint was already attempted; refusing a retry'
    # The last heap read before the one-shot intent (only the rollback proof
    # follows it): a census that no longer fits is never opened. Nothing has
    # been written, so this break may still be used at a drained boundary.
    if [ "$CHECKPOINT_PREDECESSOR_SHA" = "$CHECKPOINT_EED_SHA" ] && ! legacy_census_fits; then
      legacy_entry_trace refused census_does_not_fit
      LEGACY_ENTRY_DEADLINE_MS=0
      release_engine_lock
      switch_to_drained_predecessor_cutover
      continue
    fi
    # This provisional deadline bounds predecessor proof only. It is not
    # persisted as a cutover certificate. The checkpoint and its cleanup
    # consume up to LEGACY_CHECKPOINT_BUDGET_SECONDS of the candidate-proof
    # budget; the certificate read after them demands LEGACY_MIN_BREAK_REMAINING_MS.
    BREAK_END_EPOCH="$LEGACY_COUNTDOWN_END"
    ROLLBACK_PROOF_STARTED_MS="$(date +%s%3N)"
    prove_rollback_readiness
    # Measure the real cost of this host's rollback proof, the dominant entry
    # term, and log it against the entry allowance inside the legacy budget.
    # The admission headroom it feeds forward is doubled for margin and then
    # clamped to BREAK_ENTRY_BUDGET_CEILING_MS, which is 0 while the budget
    # already contains the entry: a threshold above 285000 can never be met
    # by a 300000ms countdown that has paid ~15000ms of entry, so demanding
    # it would defer every break for ever instead of refusing this one.
    ROLLBACK_PROOF_MS=$(( $(date +%s%3N) - ROLLBACK_PROOF_STARTED_MS ))
    echo "[engine-release-transaction] prove_rollback_readiness took ${ROLLBACK_PROOF_MS}ms of the ${LEGACY_ENTRY_ALLOWANCE_MS}ms entry allowance inside the ${LEGACY_CHECKPOINT_BUDGET_SECONDS}s legacy checkpoint budget"
    BREAK_ENTRY_BUDGET_MS=$(( ROLLBACK_PROOF_MS * 2 ))
    [ "$BREAK_ENTRY_BUDGET_MS" -ge 0 ] || BREAK_ENTRY_BUDGET_MS=0
    [ "$BREAK_ENTRY_BUDGET_MS" -le "$BREAK_ENTRY_BUDGET_CEILING_MS" ] \
      || BREAK_ENTRY_BUDGET_MS="$BREAK_ENTRY_BUDGET_CEILING_MS"
    record_floor_runtime_entry
    LEGACY_CHECKPOINT_ATTEMPTED=1
    legacy_entry_trace checkpoint verified
    set +e
    "$LEGACY_CHECKPOINT" "$RUN_ID" "$((ENTRY_STARTED_MS + LEGACY_CHECKPOINT_BUDGET_SECONDS * 1000))" "$LEGACY_ENTRY_BREAK_END_EPOCH" "$SHA" "$TARGET_IMAGE_ID" "$EXPECTED_SERVER_TREE"
    LEGACY_CHECKPOINT_RC=$?
    set -e
    if [ "$LEGACY_CHECKPOINT_RC" = 0 ]; then
      legacy_entry_trace completed verified
    else
      legacy_entry_trace refused checkpoint_refused
    fi
    LEGACY_ENTRY_DEADLINE_MS=0
    if [ "$LEGACY_CHECKPOINT_RC" = 75 ]; then
      # The helper refused ABOVE its durable one-shot intent: this attempt
      # arrived too late in the break, and nothing was attempted. That is a
      # different fact from "the checkpoint is unsafe", and until 2026-09-21
      # both ended the release for good - so a run that merely mistimed its
      # arrival burned the whole window, roughly fifteen times in one day.
      # Prove the non-action from the filesystem rather than trusting the exit
      # code: an intent file here would mean the operation really did start,
      # and then a retry stays forbidden however the helper exited. Anything
      # other than a clean, absent intent is a die, so this fails closed.
      [ ! -e "$REQUEST_ROOT/$RUN_ID.legacy-checkpoint-intent" ] \
        && [ ! -L "$REQUEST_ROOT/$RUN_ID.legacy-checkpoint-intent" ] \
        || die 'legacy checkpoint deferred but its durable intent exists; refusing a retry'
      if [ "$FLOOR_DISPOSITION" = never-entered ]; then
        # Exit75 plus the absent one-shot intent proves this fresh checkpoint
        # never acted. Retire only this entry marker while the owned lock is
        # held; an interrupted/uncertain checkpoint keeps its recovery owner.
        python3 - "$REQUEST_ROOT" "$RUN_ID" <<'FLOOR_NO_ACTION'
import os, pathlib, sys
root = pathlib.Path(sys.argv[1])
(root / (sys.argv[2] + ".activation-entry")).unlink()
fd = os.open(root, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
try: os.fsync(fd)
finally: os.close(fd)
FLOOR_NO_ACTION
      elif [ "$FLOOR_DISPOSITION" = announced ]; then
        python3 "$CONTROL_DIR/engine-release-activation-floor.py" checkpoint-no-action           --repo "$REPO_DIR" --target "$SHA" --control "$CONTROL_SHA"           --deadline "$MUTATION_DEADLINE_EPOCH" --request-root "$REQUEST_ROOT" --run-id "$RUN_ID"           --state-root "${ENGINE_RELEASE_STATE_DIR:-/var/lib/club-arena}"           >/dev/null || die 'checkpoint no-action could not retain announcement ownership'
      fi
      LEGACY_CHECKPOINT_ATTEMPTED=0
      BREAK_END_EPOCH=0
      release_engine_lock
      RECOVERY_ADMISSION_MISSED=1
      echo "[engine-release-transaction] the legacy checkpoint entry did not fit inside this break and nothing was attempted; waiting for a later certificate"
      bounded_sleep 15
      continue
    fi
    if [ "$LEGACY_CHECKPOINT_RC" = 70 ]; then
      # The helper's own name for "this run key already opened the one-shot".
      # Reachable only if the durable intent appeared between the check above
      # and this call, which is another process using our run key: still a
      # refusal, and still named rather than a traceback.
      die 'the legacy checkpoint refused as already entered under this run key; its durable intent exists and nothing was re-attempted - dispatch a new run key'
    fi
    [ "$LEGACY_CHECKPOINT_RC" = 0 ] \
      || die 'legacy checkpoint or cleanup refused; release cannot continue'
    BREAK_END_EPOCH=0
  fi
  set +e
  if [ "$LEGACY_CHECKPOINT_ATTEMPTED" = 1 ]; then
    # Only a legacy checkpoint that actually ran is read against the smaller
    # post-checkpoint minimum; every other locked read keeps the strict one.
    CERTIFICATE_MIN_BREAK_MS="$LEGACY_MIN_BREAK_REMAINING_MS"
    BREAK_REMAINING_MS="$(maintenance_certificate "$LEGACY_MIN_BREAK_REMAINING_MS")"
  else
    # The entry between the admission above and this read is budgeted, so this
    # rung sits BREAK_LOCKED_ENTRY_SECONDS below it. Demanding the admission's
    # own figure again is the deficit one gate later, every time.
    CERTIFICATE_MIN_BREAK_MS="$BREAK_LOCKED_MIN_BREAK_MS"
    BREAK_REMAINING_MS="$(maintenance_certificate "$BREAK_LOCKED_MIN_BREAK_MS")"
  fi
  CERTIFICATE_RC=$?
  set -e
  if [ "$LEGACY_CHECKPOINT_ATTEMPTED" = 1 ] && [ "$CERTIFICATE_RC" -ne 0 ]; then
    die "legacy checkpoint did not retain the full restart certificate and ${LEGACY_MIN_BREAK_REMAINING_MS}ms legacy reserve (${BREAK_REMAINING_MS:-0}ms remaining, certificate rc $CERTIFICATE_RC)"
  fi
  if [ "$CERTIFICATE_RC" -eq 2 ]; then
    note_missed_admission "${BREAK_REMAINING_MS:-0}"
    release_engine_lock
    echo "[engine-release-transaction] the locked table break has ${BREAK_REMAINING_MS:-0}ms remaining, below the ${CERTIFICATE_MIN_BREAK_MS}ms candidate-and-recovery budget; waiting for a later certificate"
    bounded_sleep 15
    continue
  fi
  if [ "$CERTIFICATE_RC" -ne 0 ]; then
    release_engine_lock
    bounded_sleep 15
    continue
  fi
  BREAK_END_EPOCH=$(( $(date +%s) + (BREAK_REMAINING_MS / 1000) ))
  persist_break_deadline
  assert_break_proof_time

  # The five-minute lane is conditional on an immediately measurable live,
  # exact rollback source with a fresh elected database leader.
  # It is not pre-started. This proof is deliberately before
  # prepare, token consumption, autoheal fencing, or serving-process replacement.
  prove_rollback_readiness
  validate_candidate_image
  STRANGERS="$(bounded_break_command 10 docker ps --filter label=sp.role=engine --format '{{.Names}}' \
    | grep -v "^$CONTAINER$" || true)"
  [ -z "$STRANGERS" ] || die 'an unmanaged engine container is running on this host'

  record_floor_runtime_entry
  set +e
  PREPARE_OUTPUT="$(bounded_break_command 10 "$RELEASE_SEAL" prepare \
    --sha "$SHA" --image "$TARGET_IMAGE_ID" --mode "$SEAL_MODE" --repo "$REPO_DIR" \
    --run-id "$RUN_ID" --run-url "$RUN_URL" --actor "$ACTOR" \
    --reason "$SEAL_PREPARE_REASON" 2>&1)"
  PREPARE_RC=$?
  set -e
  if [ "$PREPARE_RC" -eq 0 ]; then
    TOKEN="$PREPARE_OUTPUT"
    break
  fi

  read_pending_owner
  FOREIGN_RUN="$PENDING_RUN"
  if [ "$PENDING_STATE" != active ]; then
    die 'release seal refused the candidate (output withheld because the prepare channel may contain a token)'
  fi
  if [ "$FOREIGN_RUN" = "$RUN_ID" ]; then
    # The prepare process may have been interrupted after fsyncing its receipt
    # but before returning the one-use token. No candidate can have consumed a
    # token this shell never received, so clear exactly this run and retry from
    # a fresh certified boundary instead of waiting on itself until expiry.
    recover_pending_owner "$RUN_ID"
    MUTATION_STARTED=0
    release_engine_lock
    clear_break_deadline || die 'could not durably retire the abandoned break deadline'
    BREAK_END_EPOCH=0
    continue
  fi
  FOREIGN_STATE="$(bounded_break_command 5 systemctl show "club-arena-engine-release-v1@$FOREIGN_RUN.service" \
    -p ActiveState --value 2>/dev/null || true)"
  case "$FOREIGN_STATE" in
    active|activating|deactivating)
      echo "[engine-release-transaction] prior release $FOREIGN_RUN is $FOREIGN_STATE; yielding the engine lock"
      release_engine_lock
      clear_break_deadline || die 'could not durably retire the yielded break deadline'
      BREAK_END_EPOCH=0
      bounded_sleep 15
      ;;
    *)
      # The previous unit is terminal or missing but its exact pending receipt
      # survived a crash. Clear only that owner, restore the durable desired
      # release under this already-held engine lock, then re-read the break.
      recover_pending_owner "$FOREIGN_RUN"
      MUTATION_STARTED=0
      release_engine_lock
      clear_break_deadline || die 'could not durably retire the recovered break deadline'
      BREAK_END_EPOCH=0
      ;;
  esac
done

[[ "$TOKEN" =~ ^[0-9a-f]{64}$ ]] || die 'release seal did not issue a valid one-use token'
PREPARED=1
MUTATION_STARTED=1
assert_time_remaining
assert_break_proof_time

bounded_break_command 10 docker container inspect sp-autoheal >/dev/null
bounded_break_command 20 docker stop -t 15 sp-autoheal >/dev/null
[ "$(bounded_break_command 10 docker container inspect -f '{{.State.Status}}' sp-autoheal)" = exited ] \
  || die 'autoheal did not stop before the compatibility trial'

# The replacement consumes the same absolute candidate-proof deadline as its
# subsequent identity/database proof. A second 75-second cap rejected a valid
# owner window after a measured 63-second outgoing stop (40220380663). The
# bounded helper clamps this request to the time actually left, minus its
# TERM/KILL slack; the 135-second rollback reserve is never available here.
bounded_break_command "$BREAK_CUTOVER_PROOF_SECONDS" env \
  ENGINE_UP_LOCK_HELD=1 ENGINE_RELEASE_TOKEN_FD=3 IMAGE="$TARGET_IMAGE_ID" \
  CONTAINER="$CONTAINER" ENV_FILE="$ENV_FILE" "$ENGINE_UP" 3<<<"$TOKEN" \
  || die 'candidate replacement exceeded its bounded cutover budget'
unset TOKEN

CANDIDATE_CID="$(bounded_break_command 10 docker container inspect -f '{{.Id}}' "$CONTAINER")"
CANDIDATE_STARTED_AT="$(bounded_break_command 10 docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")"
[[ "$CANDIDATE_CID" =~ ^[0-9a-f]{64}$ ]] || die 'candidate container ID is invalid'
[ -n "$CANDIDATE_STARTED_AT" ] || die 'candidate start generation is missing'

# THE CANDIDATE IS NOTICED THE SECOND IT IS READY (2026-10-24). These loops
# polled every 5 s, so on average 2.5 s (up to 5 s) of a ready candidate's
# break was spent asleep, twice, before the final database proof. Release
# e4f793b6 reached that proof 7-10 s too late for its 17 s floor above the
# rollback reserve and rolled back. The candidate is polled every second; the
# total windows (180 s local, 90 s public), every proof and every budget are
# unchanged. A poll is one bounded loopback or public health read.
for attempt in $(seq 1 180); do
  assert_time_remaining
  assert_break_proof_time
  CANDIDATE_INSTANCE="$(health_instance 'http://127.0.0.1:8080/health')" && break
  [ "$attempt" = 180 ] && die 'candidate never served exact local release health'
  bounded_sleep 1
done
for attempt in $(seq 1 90); do
  assert_time_remaining
  assert_break_proof_time
  PUBLIC_INSTANCE="$(health_instance "$PUBLIC_URL/health?nocache=$(date +%s%N)")" || PUBLIC_INSTANCE=''
  [ "$PUBLIC_INSTANCE" = "$CANDIDATE_INSTANCE" ] && break
  [ "$attempt" = 90 ] && die 'public proxy never served the exact candidate release'
  bounded_sleep 1
done

# Main and the durable high-water may advance during the cold-start/public
# proof. Recheck containment and forward ordering before committing this seal.
#
# AGAINST THE MAIN ALREADY FETCHED (2026-10-23). This recheck used to fetch
# protected main from GitHub again, inside what was left of the break after the
# candidate's cold start and public proof. 2026-10-23 05:10 UTC, release
# 734578ad: the candidate was healthy and public at 05:11:13, five seconds of
# proof budget remained, and the transaction died "source verification
# deadline expired before protected-main fetch". The supervisor restored the
# previous release and the break was re-run an hour later: three restarts of
# every table for one release. A fetch adds nothing here. New protected-main
# merges never revoke a forward target (see source_target_is_current), main is
# rewind-guarded, and the one thing that can revoke this target during the
# proof - a newer sealed high-water - is read from the local seal, which the
# local-main mode still does, together with every containment proof.
source_target_is_current local-main
assert_break_proof_time
ACTUAL_CID="$(bounded_break_command 10 docker container inspect -f '{{.Id}}' "$CONTAINER")"
ACTUAL_STARTED_AT="$(bounded_break_command 10 docker container inspect -f '{{.State.StartedAt}}' "$CONTAINER")"
ACTUAL_IMAGE_ID="$(bounded_break_command 10 docker container inspect -f '{{.Image}}' "$CONTAINER")"
ACTUAL_RELEASE="$(bounded_break_command 10 docker container inspect -f '{{index .Config.Labels "sp.release.sha"}}' "$CONTAINER")"
[ "$ACTUAL_CID" = "$CANDIDATE_CID" ] \
  && [ "$ACTUAL_STARTED_AT" = "$CANDIDATE_STARTED_AT" ] \
  && [ "$ACTUAL_IMAGE_ID" = "$TARGET_IMAGE_ID" ] \
  && [ "$ACTUAL_RELEASE" = "$SHA" ] \
  || die 'candidate generation changed during compatibility proof'
PRECOMMIT_LOCAL_INSTANCE="$(health_instance 'http://127.0.0.1:8080/health')" \
  || die 'candidate lost exact local health before seal commit'
PRECOMMIT_PUBLIC_INSTANCE="$(health_instance "$PUBLIC_URL/health?nocache=$(date +%s%N)")" \
  || die 'candidate lost exact public health before seal commit'
[ "$PRECOMMIT_LOCAL_INSTANCE" = "$CANDIDATE_INSTANCE" ] \
  && [ "$PRECOMMIT_PUBLIC_INSTANCE" = "$CANDIDATE_INSTANCE" ] \
  || die 'candidate process identity changed before seal commit'

# The elected-leader witness is deliberately last. Source freshness can wait
# on Git and must never age a previously accepted heartbeat before the seal
# moves. A 15-second maximum heartbeat age binds this exact process identity
# to the database immediately before the bounded commit.
REMAINING="$(remaining_seconds)" || die 'deadline expired before final database proof'
DB_TIMEOUT="$REMAINING"
BREAK_PROOF_REMAINING="$(break_proof_seconds)" \
  || die 'maintenance break proof budget expired before final database proof'
[ "$DB_TIMEOUT" -le "$BREAK_PROOF_REMAINING" ] || DB_TIMEOUT="$BREAK_PROOF_REMAINING"
[ "$DB_TIMEOUT" -le 60 ] || DB_TIMEOUT=60
[ "$DB_TIMEOUT" -ge 17 ] || die 'insufficient maintenance-break budget for final database proof'
DB_TIMEOUT=$((DB_TIMEOUT - 2))
timeout --signal=TERM --kill-after=1s "${DB_TIMEOUT}s" \
  "$DATABASE_PROOF" --env-file "$ENV_FILE" --sha "$SHA" --instance-id "$CANDIDATE_INSTANCE" \
  --timeout-seconds "$DB_TIMEOUT" --poll-seconds 5 --max-heartbeat-age-seconds 15
assert_time_remaining
assert_break_proof_time

set +e
SEAL_REASON='local, public, and elected-leader compatibility proofs passed'
if [ -n "$SUPERSEDED_BY" ]; then
  # Written into the durable seal and therefore into engine-release-audit.jsonl.
  # Record which newer engine commit was known when this forward release sealed.
  SEAL_REASON="$SEAL_REASON; forward release behind protected-main engine $SUPERSEDED_BY"
fi
if [ -n "${DRILL_MODE:-}" ]; then
  SEAL_REASON="$SEAL_REASON; engine drill $DRILL_MODE: $DRILL_REASON"
fi
bounded_break_command 10 "$RELEASE_SEAL" commit \
  --sha "$SHA" --image "$TARGET_IMAGE_ID" --container "$CONTAINER" \
  --container-id "$CANDIDATE_CID" --started-at "$CANDIDATE_STARTED_AT" \
  --run-id "$RUN_ID" --run-url "$RUN_URL" --actor "$ACTOR" \
  --reason "$SEAL_REASON"
COMMIT_RC=$?
set -e
[ "$COMMIT_RC" -eq 0 ] \
  || echo '[engine-release-transaction] seal response uncertain; requiring fsynced receipt'
bounded_break_command 10 "$RELEASE_SEAL" attest-commit \
  --sha "$SHA" --image-id "$TARGET_IMAGE_ID" --run-id "$RUN_ID" >/dev/null \
  || die 'durable seal does not attest this exact release transaction'

bounded_break_command 10 docker tag "$TARGET_IMAGE_ID" "$IMAGE_REPO:current"
bounded_break_command 10 docker update --restart always "$CONTAINER" >/dev/null
bounded_break_command 10 docker start sp-autoheal >/dev/null
[ "$(bounded_break_command 10 \
  docker container inspect -f '{{.HostConfig.RestartPolicy.Name}}' "$CONTAINER")" = always ]
[ "$(bounded_break_command 10 \
  docker container inspect -f '{{.State.Status}}' sp-autoheal)" = running ]
FINAL_LOCAL_INSTANCE="$(health_instance 'http://127.0.0.1:8080/health')" \
  || die 'sealed engine failed final local health proof'
FINAL_PUBLIC_INSTANCE="$(health_instance "$PUBLIC_URL/health?nocache=$(date +%s%N)")" \
  || die 'sealed engine failed final public proof'
[ "$FINAL_LOCAL_INSTANCE" = "$CANDIDATE_INSTANCE" ] \
  && [ "$FINAL_PUBLIC_INSTANCE" = "$CANDIDATE_INSTANCE" ] \
  || die 'sealed engine identity changed after commit'
[ "$(date +%s)" -lt "$BREAK_END_EPOCH" ] \
  || die 'sealed candidate proof escaped the announced maintenance break'
persist_result sealed "$FINAL_LOCAL_INSTANCE"
record_drill_receipt sealed "$FINAL_LOCAL_INSTANCE"
timeout --signal=TERM --kill-after=3s 65s "$CONTROL_DIR/retain-engine-images.sh" \
  || echo '[engine-release-transaction] WARN: post-receipt image retention failed' >&2
